# db544ae8-d4cb-41ff-82bd-ab28e3064a57 - HospitalNotification Testscripts v3.0.3

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **db544ae8-d4cb-41ff-82bd-ab28e3064a57**

## Bundle: db544ae8-d4cb-41ff-82bd-ab28e3064a57



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "db544ae8-d4cb-41ff-82bd-ab28e3064a57",
  "meta" : {
    "profile" : ["http://medcomfhir.dk/ig/hospitalnotification/StructureDefinition/medcom-hospitalNotification-message"]
  },
  "type" : "message",
  "timestamp" : "2026-03-01T15:00:00+01:00",
  "entry" : [{
    "fullUrl" : "https://medcomfhir.dk/ig/hospitalnotification/MessageHeader/c0aea49f-8851-4a52-965f-0aab70c993c9",
    "resource" : {
      "resourceType" : "MessageHeader",
      "id" : "c0aea49f-8851-4a52-965f-0aab70c993c9",
      "meta" : {
        "profile" : ["http://medcomfhir.dk/ig/hospitalnotification/StructureDefinition/medcom-hospitalNotification-messageHeader"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MessageHeader_c0aea49f-8851-4a52-965f-0aab70c993c9\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MessageHeader c0aea49f-8851-4a52-965f-0aab70c993c9</b></p><a name=\"c0aea49f-8851-4a52-965f-0aab70c993c9\"> </a><a name=\"hcc0aea49f-8851-4a52-965f-0aab70c993c9\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-medcom-hospitalNotification-messageHeader.html\">MedComHospitalNotificationMessageHeader</a></p></div><p><b>event</b>: <a href=\"http://medcomfhir.dk/ig/terminology/1.5.0/CodeSystem-medcom-messaging-eventCodes.html#medcom-messaging-eventCodes-hospital-notification-message\">MedComMessagingEventCodes: hospital-notification-message</a> (Hospital Notification Message)</p><h3>Destinations</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Extension</b></td><td><b>Endpoint</b></td><td><b>Receiver</b></td></tr><tr><td style=\"display: none\">*</td><td/><td><a href=\"https://sor2.sum.dsdn.dk/#id=953741000016009\">https://sor2.sum.dsdn.dk/#id=953741000016009</a></td><td><a href=\"Organization-50fe01f9-7668-4b1b-8687-76522881411b.html\">Organization Plejecenter Herlev</a></td></tr></table><p><b>sender</b>: <a href=\"Organization-6df69996-8df7-4642-8c93-2e2c5f5bb997.html\">Organization Hjerteafdelingen på Herlev og Gentofte hospital</a></p><h3>Sources</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Endpoint</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"https://sor2.sum.dsdn.dk/#id=265161000016000\">https://sor2.sum.dsdn.dk/#id=265161000016000</a></td></tr></table><p><b>focus</b>: <a href=\"Encounter-066da6fa-0d49-480f-8b39-d1926c9f5185.html\">Encounter: status = in-progress; class = inpatient encounter (ActCode#IMP); period = 2026-03-01 15:00:00+0100 --&gt; (ongoing)</a></p></div>"
      },
      "eventCoding" : {
        "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-messaging-eventCodes",
        "code" : "hospital-notification-message"
      },
      "destination" : [{
        "extension" : [{
          "url" : "http://medcomfhir.dk/ig/messaging/StructureDefinition/medcom-messaging-destinationUseExtension",
          "valueCoding" : {
            "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-messaging-destinationUse",
            "code" : "primary"
          }
        }],
        "endpoint" : "https://sor2.sum.dsdn.dk/#id=953741000016009",
        "receiver" : {
          "reference" : "Organization/50fe01f9-7668-4b1b-8687-76522881411b"
        }
      }],
      "sender" : {
        "reference" : "Organization/6df69996-8df7-4642-8c93-2e2c5f5bb997"
      },
      "source" : {
        "endpoint" : "https://sor2.sum.dsdn.dk/#id=265161000016000"
      },
      "focus" : [{
        "reference" : "Encounter/066da6fa-0d49-480f-8b39-d1926c9f5185"
      }]
    }
  },
  {
    "fullUrl" : "https://medcomfhir.dk/ig/hospitalnotification/Patient/fea1dc5b-dd69-406f-869d-07c06b4abf08",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "fea1dc5b-dd69-406f-869d-07c06b4abf08",
      "meta" : {
        "profile" : ["http://medcomfhir.dk/ig/core/StructureDefinition/medcom-core-patient"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_fea1dc5b-dd69-406f-869d-07c06b4abf08\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient fea1dc5b-dd69-406f-869d-07c06b4abf08</b></p><a name=\"fea1dc5b-dd69-406f-869d-07c06b4abf08\"> </a><a name=\"hcfea1dc5b-dd69-406f-869d-07c06b4abf08\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://medcomfhir.dk/ig/core/2.3.0/StructureDefinition-medcom-core-patient.html\">MedComCorePatient</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Elmer (official) (no stated gender), DoB Unknown ( urn:oid:1.2.208.176.1.2#DkCoreDanishCivilRegistrationSystem#2509479989)</p><hr/></div>"
      },
      "identifier" : [{
        "system" : "urn:oid:1.2.208.176.1.2",
        "value" : "2509479989"
      }],
      "name" : [{
        "use" : "official",
        "family" : "Elmer"
      }]
    }
  },
  {
    "fullUrl" : "https://medcomfhir.dk/ig/hospitalnotification/Encounter/066da6fa-0d49-480f-8b39-d1926c9f5185",
    "resource" : {
      "resourceType" : "Encounter",
      "id" : "066da6fa-0d49-480f-8b39-d1926c9f5185",
      "meta" : {
        "profile" : ["http://medcomfhir.dk/ig/hospitalnotification/StructureDefinition/medcom-hospitalNotification-encounter"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Encounter_066da6fa-0d49-480f-8b39-d1926c9f5185\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Encounter 066da6fa-0d49-480f-8b39-d1926c9f5185</b></p><a name=\"066da6fa-0d49-480f-8b39-d1926c9f5185\"> </a><a name=\"hc066da6fa-0d49-480f-8b39-d1926c9f5185\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-medcom-hospitalNotification-encounter.html\">MedComHospitalNotificationEncounter</a></p></div><p><b>status</b>: In Progress</p><p><b>class</b>: <a href=\"http://terminology.hl7.org/7.3.0/CodeSystem-v3-ActCode.html#v3-ActCode-IMP\">ActCode: IMP</a> (inpatient encounter)</p><p><b>subject</b>: <a href=\"Patient-fea1dc5b-dd69-406f-869d-07c06b4abf08.html\">Elmer (official) (no stated gender), DoB Unknown ( urn:oid:1.2.208.176.1.2#DkCoreDanishCivilRegistrationSystem#2509479989)</a></p><p><b>episodeOfCare</b>: Identifier: <code>https://sor2.sum.dsdn.dk/#id=265161000016000</code>/c10697b6-8d7a-4d2d-ae93-f7f56abd52cc</p><p><b>period</b>: 2026-03-01 15:00:00+0100 --&gt; (ongoing)</p><p><b>serviceProvider</b>: <a href=\"Organization-6df69996-8df7-4642-8c93-2e2c5f5bb997.html\">Organization Hjerteafdelingen på Herlev og Gentofte hospital</a></p></div>"
      },
      "status" : "in-progress",
      "class" : {
        "system" : "http://terminology.hl7.org/CodeSystem/v3-ActCode",
        "code" : "IMP"
      },
      "subject" : {
        "reference" : "Patient/fea1dc5b-dd69-406f-869d-07c06b4abf08"
      },
      "episodeOfCare" : [{
        "identifier" : {
          "system" : "https://sor2.sum.dsdn.dk/#id=265161000016000",
          "value" : "c10697b6-8d7a-4d2d-ae93-f7f56abd52cc"
        }
      }],
      "period" : {
        "start" : "2026-03-01T15:00:00+01:00"
      },
      "serviceProvider" : {
        "reference" : "Organization/6df69996-8df7-4642-8c93-2e2c5f5bb997"
      }
    }
  },
  {
    "fullUrl" : "https://medcomfhir.dk/ig/hospitalnotification/Organization/6df69996-8df7-4642-8c93-2e2c5f5bb997",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "6df69996-8df7-4642-8c93-2e2c5f5bb997",
      "meta" : {
        "profile" : ["http://medcomfhir.dk/ig/messaging/StructureDefinition/medcom-messaging-organization"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_6df69996-8df7-4642-8c93-2e2c5f5bb997\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization 6df69996-8df7-4642-8c93-2e2c5f5bb997</b></p><a name=\"6df69996-8df7-4642-8c93-2e2c5f5bb997\"> </a><a name=\"hc6df69996-8df7-4642-8c93-2e2c5f5bb997\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://medcomfhir.dk/ig/messaging/2.1.0/StructureDefinition-medcom-messaging-organization.html\">MedComMessagingOrganization</a></p></div><p><b>identifier</b>: <code>https://www.gs1.org/gln</code>/5790000209354, <code>urn:oid:1.2.208.176.1.1</code>/265161000016000</p><p><b>name</b>: Hjerteafdelingen på Herlev og Gentofte hospital</p></div>"
      },
      "identifier" : [{
        "system" : "https://www.gs1.org/gln",
        "value" : "5790000209354"
      },
      {
        "system" : "urn:oid:1.2.208.176.1.1",
        "value" : "265161000016000"
      }],
      "name" : "Hjerteafdelingen på Herlev og Gentofte hospital"
    }
  },
  {
    "fullUrl" : "https://medcomfhir.dk/ig/hospitalnotification/Organization/50fe01f9-7668-4b1b-8687-76522881411b",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "50fe01f9-7668-4b1b-8687-76522881411b",
      "meta" : {
        "profile" : ["http://medcomfhir.dk/ig/messaging/StructureDefinition/medcom-messaging-organization"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_50fe01f9-7668-4b1b-8687-76522881411b\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization 50fe01f9-7668-4b1b-8687-76522881411b</b></p><a name=\"50fe01f9-7668-4b1b-8687-76522881411b\"> </a><a name=\"hc50fe01f9-7668-4b1b-8687-76522881411b\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://medcomfhir.dk/ig/messaging/2.1.0/StructureDefinition-medcom-messaging-organization.html\">MedComMessagingOrganization</a></p></div><p><b>identifier</b>: <code>https://www.gs1.org/gln</code>/5790001348120, <code>urn:oid:1.2.208.176.1.1</code>/953741000016009</p><p><b>name</b>: Plejecenter Herlev</p></div>"
      },
      "identifier" : [{
        "system" : "https://www.gs1.org/gln",
        "value" : "5790001348120"
      },
      {
        "system" : "urn:oid:1.2.208.176.1.1",
        "value" : "953741000016009"
      }],
      "name" : "Plejecenter Herlev"
    }
  },
  {
    "fullUrl" : "https://medcomfhir.dk/ig/hospitalnotification/Provenance/d23080f7-8c49-4a7c-9ff3-ca4b0d1ed766",
    "resource" : {
      "resourceType" : "Provenance",
      "id" : "d23080f7-8c49-4a7c-9ff3-ca4b0d1ed766",
      "meta" : {
        "profile" : ["http://medcomfhir.dk/ig/messaging/StructureDefinition/medcom-messaging-provenance"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Provenance_d23080f7-8c49-4a7c-9ff3-ca4b0d1ed766\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Provenance d23080f7-8c49-4a7c-9ff3-ca4b0d1ed766</b></p><a name=\"d23080f7-8c49-4a7c-9ff3-ca4b0d1ed766\"> </a><a name=\"hcd23080f7-8c49-4a7c-9ff3-ca4b0d1ed766\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://medcomfhir.dk/ig/messaging/2.1.0/StructureDefinition-medcom-messaging-provenance.html\">MedComMessagingProvenance</a></p></div><p>Provenance for <a href=\"MessageHeader-c0aea49f-8851-4a52-965f-0aab70c993c9.html\">MessageHeader: event[x] = Hospital Notification Message (MedComMessagingEventCodes#hospital-notification-message)</a></p><p>Summary</p><table class=\"grid\"><tr><td>Occurrence</td><td>2026-03-01 15:00:00+0100</td></tr><tr><td>Recorded</td><td>2026-03-01 15:00:00+0100</td></tr><tr><td>Activity</td><td><span title=\"Codes:{http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-messaging-activityCodes admit-inpatient}\">Start hospital stay - admitted</span></td></tr></table><p><b>Agents</b></p><table class=\"grid\"><tr><td><b>who</b></td></tr><tr><td><a href=\"Organization-6df69996-8df7-4642-8c93-2e2c5f5bb997.html\">Organization Hjerteafdelingen på Herlev og Gentofte hospital</a></td></tr></table></div>"
      },
      "target" : [{
        "reference" : "MessageHeader/c0aea49f-8851-4a52-965f-0aab70c993c9"
      }],
      "occurredDateTime" : "2026-03-01T15:00:00+01:00",
      "recorded" : "2026-03-01T15:00:00+01:00",
      "activity" : {
        "coding" : [{
          "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-messaging-activityCodes",
          "code" : "admit-inpatient"
        }]
      },
      "agent" : [{
        "who" : {
          "reference" : "Organization/6df69996-8df7-4642-8c93-2e2c5f5bb997"
        }
      }],
      "entity" : [{
        "role" : "revision",
        "what" : {
          "reference" : "MessageHeader/i50fc5fe-2d11-4ef3-acac-2e2e5c399006"
        }
      }]
    }
  },
  {
    "fullUrl" : "https://medcomfhir.dk/ig/hospitalnotification/Provenance/6d4ab23d-9c68-476d-b8d1-ee03ea345241",
    "resource" : {
      "resourceType" : "Provenance",
      "id" : "6d4ab23d-9c68-476d-b8d1-ee03ea345241",
      "meta" : {
        "profile" : ["http://medcomfhir.dk/ig/messaging/StructureDefinition/medcom-messaging-provenance"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Provenance_6d4ab23d-9c68-476d-b8d1-ee03ea345241\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Provenance 6d4ab23d-9c68-476d-b8d1-ee03ea345241</b></p><a name=\"6d4ab23d-9c68-476d-b8d1-ee03ea345241\"> </a><a name=\"hc6d4ab23d-9c68-476d-b8d1-ee03ea345241\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://medcomfhir.dk/ig/messaging/2.1.0/StructureDefinition-medcom-messaging-provenance.html\">MedComMessagingProvenance</a></p></div><p>Provenance for <a href=\"MessageHeader/i50fc5fe-2d11-4ef3-acac-2e2e5c399006\">MessageHeader/i50fc5fe-2d11-4ef3-acac-2e2e5c399006</a></p><p>Summary</p><table class=\"grid\"><tr><td>Occurrence</td><td>2026-02-28 14:00:06+0100</td></tr><tr><td>Recorded</td><td>2026-02-28 14:00:06+0100</td></tr><tr><td>Activity</td><td><span title=\"Codes:{http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-messaging-activityCodes admit-emergency}\">Start hospital stay - acute ambulant</span></td></tr></table><p><b>Agents</b></p><table class=\"grid\"><tr><td><b>who</b></td></tr><tr><td><a href=\"Organization-6df69996-8df7-4642-8c93-2e2c5f5bb997.html\">Organization Hjerteafdelingen på Herlev og Gentofte hospital</a></td></tr></table></div>"
      },
      "target" : [{
        "reference" : "MessageHeader/i50fc5fe-2d11-4ef3-acac-2e2e5c399006"
      }],
      "occurredDateTime" : "2026-02-28T14:00:06+01:00",
      "recorded" : "2026-02-28T14:00:06+01:00",
      "activity" : {
        "coding" : [{
          "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-messaging-activityCodes",
          "code" : "admit-emergency"
        }]
      },
      "agent" : [{
        "who" : {
          "reference" : "Organization/6df69996-8df7-4642-8c93-2e2c5f5bb997"
        }
      }]
    }
  }]
}

```
