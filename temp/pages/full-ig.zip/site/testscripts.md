# Testscripts - HospitalNotification Testscripts v3.0.3

* [**Table of Contents**](toc.md)
* **Testscripts**

## Testscripts

The test scripts are created by MedCom for testing in [TouchStone](https://touchstone.aegis.net/touchstone/) during MedCom test and certification, both self- and live test. However, the test scripts may be used locally by vendors in their own testsetup, e.g. during code development or test.

Test scripts presented in this IG are all based on the [FHIR TestScript resource](https://www.hl7.org/fhir/testscript.html). They are created using FSH and published using the FHIR publisher.

### Before getting started

Use cases described in the [use case document](https://medcomdk.github.io/dk-medcom-hospitalnotification/#12-use-cases) will be referenced throughout this IG and they are the basis for the tests.

In addition to test scripts based on the use cases, test scripts testing **patient flows** are included. These test scripts will test different, and in some cases extended flows of the HospitalNotification use cases, that hasn't been tested in the use case focused tests. They will of course only test within the boundaries of the HospitalNotification standard and governance.

#### TouchStone and API

Before getting started with test script execution, it is necessary to have an account on TouchStone and to create a test system. Please follow [this guide to setup an account and test system](https://medcomdk.github.io/MedComLandingPage/assets/documents/TouchStoneGettingStarted.html).

#### Abbreviations and naming

**Abbreviations:**

The term 'inpatient' and abbreviation 'imp' refers to a patient who is admitted/registered as an inpatient in the hospital’s EHR system (Danish: indlagt), and the term 'emergency' and abbreviation 'emer' refers to a patient that is registered as acute ambulant in the hospital’s EHR system (Danish: akut ambulant).

The abbreviation 'tec' is used when testing the patient flow, to indicate that the test script has a technical character.

The system under test is abbreviated 'SUT'.

**Test script naming:**

Most of the send test scripts requires that SUT has executed one or more use cases in advance. These use cases are listed in the 'Precondition' columns in the tables.

**Use cases:** The name of the test scripts is constituted by HospitalNotification_Testscript_[send/receive]-[type]-[imp/emer or alternative flow or precondition], describing the type of messages being sent, or recieved. 'HospitalNotifciation_Testscript_[send/receive]-' is not shown in the naming below.

**Patient flows:** These will be named HospitalNotification_Testscript_PF-[send/receive]-[imp/emer/tec]-[number]. 'HospitalNotifciation_Testscript_' is not shown in the naming below.

### Send HospitalNotification test scripts

When sending a HospitalNotification, a POST operation is required for all types of messages, and is therefore valid for both the precondition messages and actual messages being tested.

During test and certification, vendors must conform to test scripts included in the [conformance suite for sending HospitalNotification messages.](https://touchstone.aegis.net/touchstone/conformance/current?suite=FHIR4-0-1-HospitalNotification-send-Client)

#### Use Cases

[Test scripts for test of sending use cases, can be found here in TouchStone.](https://touchstone.aegis.net/touchstone/testdefinitions?selectedTestGrp=/FHIRSandbox/MedCom/HospitalNotification/v300-send/PatientFlows&activeOnly=false&contentEntry=TEST_SCRIPTS)

| | | | | |
| :--- | :--- | :--- | :--- | :--- |
| **Inpatient** |   |   |   |   |
| [STIN](./TestScript-hospitalnotification-send-stin.md) | S1 | Send: Start hospital stay - admitted | STIN |   |
| [STIN-A1](./TestScript-hospitalnotification-send-stin-a1.md) | S1.A1 | Send: Start hospital stay - admitted, without request for a reportOfAdmission | STIN |   |
| [STOR](./TestScript-hospitalnotification-send-stor.md) | S3 | Send: Start leave | STOR | STIN |
| [SLOR](./TestScript-hospitalnotification-send-slor.md) | S4 | Send: End leave | SLOR | STIN, STOR |
| [SLHJ-imp](./TestScript-hospitalnotification-send-slhj-imp.md) | S6 | Send: End hospital stay - patient completed to home/primary sector | SLHJ | STIN |
| [MORS](./TestScript-hospitalnotification-send-mors.md) | S7 | Send: Deceased - dead at arrival to the hospital | MORS |   |
| [MORS-imp](./TestScript-hospitalnotification-send-mors-imp.md) | S7 | Send: Deceased - deceased during hospital stay | MORS | STIN |
| [MORS-STOR](./TestScript-hospitalnotification-send-mors-stor.md) | S7 | Send: Deceased - deceased during a period of leave | MORS | STIN, STOR |
| **Emergency** |   |   |   |   |
| [STAA](./TestScript-hospitalnotification-send-staa.md) | S2 | Send: Start hospital stay - acute ambulant | STAA |   |
| [SLHJ-emer](./TestScript-hospitalnotification-send-slhj-emer.md) | S6 | Send: End hospital stay - patient completed to home/primary sector | SLHJ | STAA |
| [MORS-emer](./TestScript-hospitalnotification-send-mors-emer.md) | S7 | Send: Deceased - deceased during hospital stay | MORS | STAA |
| **Inpatient** |   |   |   |   |
| [RE_STIN](./TestScript-hospitalnotification-send-re-stin.md) | S.CORR | Send: Send: Update Start hospital stay - admitted | RE_STIN | STIN |
| [RE_STOR](./TestScript-hospitalnotification-send-re-stor.md) | S.CORR | Send: Send: Update Start leave | RE_STOR | STIN, STOR |
| [RE_SLOR](./TestScript-hospitalnotification-send-re-slor.md) | S.CORR | Send: Send: Update End leave | RE_SLOR | STIN, STOR, SLOR |
| [RE_SLHJ-imp](./TestScript-hospitalnotification-send-re-slhj-imp.md) | S.CORR | Send: Send: Update End hospital stay - patient completed to home/primary sector | RE_SLHJ | STIN, SLHJ |
| [RE_MORS](./TestScript-hospitalnotification-send-re-mors.md) | S.CORR | Send: Update Deceased - dead at arrival to the hospital | RE_MORS | MORS |
| [RE_MORS-imp](./TestScript-hospitalnotification-send-re-mors-imp.md) | S.CORR | Send: Update Deceased - deceased during hospital stay | RE_MORS | STIN, MORS |
| [RE_MORS-STOR](./TestScript-hospitalnotification-send-re-mors-stor.md) | S.CORR | Send: Update Deceased - deceased during a period of leave | RE_MORS | STIN, STOR, MORS |
| **Emergency** |   |   |   |   |
| [RE_STAA](./TestScript-hospitalnotification-send-re-staa.md) | S.CORR | Send: Update Start hospital stay - acute ambulant | RE_STAA | STAA |
| [RE_SLHJ-emer](./TestScript-hospitalnotification-send-re-slhj-emer.md) | S.CORR | Send: Update End hospital stay - patient completed to home/primary sector | RE_SLHJ | STAA, SLHJ |
| [RE_MORS-emer](./TestScript-hospitalnotification-send-re-mors-emer.md) | S.CORR | Send: Update Deceased - deceased during acute ambulant | RE_MORS | STAA, MORS |
| **Inpatient** |   |   |   |   |
| [AN_STIN](./TestScript-hospitalnotification-send-an-stin.md) | S.CANC | Send: Cancellation Start hospital stay - admitted | AN_STIN | STIN |
| [AN_STOR](./TestScript-hospitalnotification-send-an-stor.md) | S.CANC | Send: Cancellation Start leave | AN_STOR | STIN, STOR |
| [AN_SLOR](./TestScript-hospitalnotification-send-an-slor.md) | S.CANC | Send: Cancellation End leave | AN_SLOR | STIN, STOR, SLOR |
| [AN_SLHJ-imp](./TestScript-hospitalnotification-send-an-slhj-imp.md) | S.CANC | Send: Cancellation End hospital stay - patient completed to home/primary sector | AN_SLHJ | STIN, SLHJ |
| [AN_MORS](./TestScript-hospitalnotification-send-an-mors.md) | S.CANC | Send: Cancellation Deceased - dead at arrival to the hospital | AN_MORS | MORS |
| [AN_MORS-imp](./TestScript-hospitalnotification-send-an-mors-imp.md) | S.CANC | Send: Cancellation Deceased - deceased during admission | AN_MORS | STIN, MORS |
| [AN_MORS-STOR](./TestScript-hospitalnotification-send-an-mors-stor.md) | S.CANC | Send: Cancellation Deceased - deceased during a period of leave | AN_MORS | STIN, STOR, MORS |
| **Emergency** |   |   |   |   |
| [AN_STAA](./TestScript-hospitalnotification-send-an-staa.md) | S.CANC | Send: Cancellation Start hospital stay - acute ambulant | AN_STAA | STAA |
| [AN_SLHJ-emer](./TestScript-hospitalnotification-send-an-slhj-emer.md) | S.CANC | Send: Cancellation End hospital stay - patient completed to home/primary sector | AN_SLHJ | STAA, SLHJ |
| [AN_MORS-emer](./TestScript-hospitalnotification-send-an-mors-emer.md) | S.CANC | Send: Cancellation Deceased - deceased during acute ambulant | AN_MORS | STAA, MORS |

#### Patient Flow

[Test scripts for test of sending patient flows, can be found here in TouchStone.](https://touchstone.aegis.net/touchstone/testdefinitions?selectedTestGrp=/FHIRSandbox/MedCom/HospitalNotification/v300-send/PatientFlows&activeOnly=false&contentEntry=TEST_SCRIPTS)

| | | |
| :--- | :--- | :--- |
| **Inpatient** |   |   |
| [PF-send-imp-01](./TestScript-hospitalnotification-PF-send-imp-01.md) | Send: Admit patient, register patient as being on leave, register patient as returned from leave, discharge patient. | STIN, STOR, SLOR, SLHJ |
| [PF-send-imp-02](./TestScript-hospitalnotification-PF-send-imp-02.md) | Send: Admit patient, register patient as being on leave, patient doesn’t return from leave, discharge patient.[1](#fn:1) | STIN, STOR, SLHJ |
| [PF-send-imp-03](./TestScript-hospitalnotification-PF-send-imp-03.md) | Send: Admit patient, register patient as being on leave, patient returns from leave, patient dies | STIN, STOR, SLOR, MORS |
| [PF-send-imp-04](./TestScript-hospitalnotification-PF-send-imp-04.md) | Send: Admit patient,**register patient as being on leave, patient returns from leave**, * to * x2 | STIN, STOR, SLOR, STOR, SLOR |
| [PF-send-imp-05](./TestScript-hospitalnotification-PF-send-imp-05.md) | Send: Admit patient, correct message due to incorrect hospital department | STIN, RE_STIN |
| [PF-send-imp-06](./TestScript-hospitalnotification-PF-send-imp-06.md) | Send: Admit patient, correct message due to incorrect time of admission | STIN, RE_STIN |
| **Emergency** |   |   |
| [PF-send-emer-01](./TestScript-hospitalnotification-PF-send-emer-01.md) | Send: Register patient as acute ambulant, correct message due to incorrect hospital department | STAA, RE_STAA |
| [PF-send-emer-02](./TestScript-hospitalnotification-PF-send-emer-02.md) | Send: Register patient as acute ambulant, correct message due to incorrect time of admission | STAA, RE_STAA |
| **Emergency/Inpatient** |   |   |
| [PF-send-emer/imp-01](./TestScript-hospitalnotification-PF-send-emer-imp-01.md) | Send: Register patient as acute ambulant, admit patient (inpatient), discharge patient | STAA, STIN, SLHJ |
| **Technical** |   |   |
| [PF-send-tec-01](./TestScript-hospitalnotification-PF-send-tec-01.md) | Send: Cancel a correction: Admit patient, correct admit patient and cancel the correction | STIN, RE_STIN, AN_STIN |
| [PF-send-tec-02](./TestScript-hospitalnotification-PF-send-tec-02.md) | Send: Send a message on the 29th of February 2024 (leap year.html) | STIN |
| [PF-send-tec-03](./TestScript-hospitalnotification-PF-send-tec-03.md) | Send dublicate: Admit patient, doesn't get acknowledged, send admit patient. IDs are handled correct | STIN, STIN |
| [PF-send-tec-04](./TestScript-hospitalnotification-PF-send-tec-04.md) | Send: Admit patient and End hospital stay in different timezones. Correct use of timezone of summertime (+02:00) and vintertime (+01:00). | STIN, SLHJ |

### Receive HospitalNotification test scripts

> Note: it is optional to run trough the receive test scripts during test and certification of receiving HospitalNotification messages.

When receiving a HospitalNotification, a GET operation is required for all types of messages, valid for both the precondition messages and actual messages being tested.

During test and certification, vendors must conform to test scripts included in the [conformance suite for receiving HospitalNotification messages.](https://touchstone.aegis.net/touchstone/conformance/current?suite=FHIR4-0-1-HospitalNotification-receive-Client)

**Test examples/fixtures:** Test examples are, in TouchStone testing, called fixtures. These fixtures are uploaded to TouchStone. During setup of a test, all relevant fixtures will be uploadet to the server used during test. From a client application e.g. a vendor's system, it is possible to request relevant fixture.

**HospitalNotifications:** Timestamps in most fixtures (HospitalNotifications) are sent between the 28th of February 2023 and 7th of March 2023. The only exception is the fixture used for PF-receive-tec-04 which is on the 28th of February 2023 and the fixture used for PF-receive-tec-05 which is on the 29th of February 2024. All corrections and cancellation messages are sent one hour after the message it revises or cancels.

All fixtures are based on the test patient:

* Family name: Elmer
* CPR-nr.: 250947-9989

#### Placeholders

[Placeholders](https://touchstone.aegis.net/touchstone/userguide/html/testscript-authoring/placeholders.html?highlight=placeholder) are used in the fixtures. Placeholders are used to ensure uniqueness in a fixture, and to ensure that vendors testing at the same time won't interfere with eachother.

**UUID:** Bundle.id will be generate during the test setup. The following line is included in the fixtures. `<id value="${UUID}"/>` Which results in the following being generated during setup. For instance: `<id value="b9b4818e-02de-4cc4-b418-d20cbc399006"/>`

**Digits:** MessageHeader.destination.endpoint and id of the MessageHeader, used in the elements MessageHeader.id, Provenance.target and Provenance.entity.what, includes the placeholder D6. The following line is included in the fixtures. `<id value="hefc6d95-6161-4493-99c9-f35948${D6}"/>` or `<endpoint value="https://sor2.sum.dsdn.dk/#id=953741000016009${D6}"/>`. 
 Which results in the following being generated during setup. For instance: `<id value="b9b4818e-02de-4cc4-b418-d20cbc399006"/>` or `<endpoint value="https://sor2.sum.dsdn.dk/#id=953741000016009"/>`

#### GET operation

When searching for a HospitalNotification message, the GET operation requires a variable to search for a specific message. The variable used in the request is constituted by client information and two search parameters 1) the destination endpoint with placeholder ${D6}, and 2) the Bundle.id.

In the test scripts, the search parameter are: `"params": "?message.destination-uri=${destinationUri-STIN}&amp;member._id=${bundleid-STIN}"` Which results in the following variable to be used in the GET operation. For instance: `http://touchstone.aegis.net:49917/fhir4-0-1/Bundle?message.destination-uri=https://sor2.sum.dsdn.dk/#id=953741000016009399006&amp;member._id=b9b4818e-02de-4cc4-b418-d20cbc399006`

#### Use Cases

[Test scripts for test of the recieving use cases, can be found here in TouchStone.](https://touchstone.aegis.net/touchstone/testdefinitions?selectedTestGrp=/FHIRSandbox/MedCom/HospitalNotification/v300-receive/UseCases&activeOnly=false&contentEntry=TEST_SCRIPTS)

| | | | | |
| :--- | :--- | :--- | :--- | :--- |
| **Inpatient** |   |   |   |   |
| [STIN](./TestScript-hospitalnotification-receive-stin.md) | R1 | Receive: Start hospital stay - admitted | STIN |   |
| [STIN-A1](./TestScript-hospitalnotification-receive-stin-a1.md) | R1.A1 | Receive: Start hospital stay - admitted, without request for reportOfAdmission | STIN |   |
| [STOR](./TestScript-hospitalnotification-receive-stor.md) | R3 | Receive: Start leave | STOR | STIN |
| [SLOR](./TestScript-hospitalnotification-receive-slor.md) | R4 | Receive: End leave | SLOR | STIN, STOR |
| [SLHJ-imp](./TestScript-hospitalnotification-receive-slhj-imp.md) | R6 | Receive: End hospital stay - patient completed to home/primary sector | SLHJ | STIN |
| [MORS](./TestScript-hospitalnotification-receive-mors.md) | R7 | Receive: Deceased - is dead at arrival to the hospital | MORS |   |
| [MORS-imp](./TestScript-hospitalnotification-receive-mors-imp.md) | R7 | Receive: Deceased - deceased during hospital stay | MORS | STIN |
| [MORS-STOR](./TestScript-hospitalnotification-receive-mors-stor.md) | R7 | Receive: Deceased - deceased during a period of leave | MORS | STIN, STOR |
| **Emergency** |   |   |   |   |
| [STAA](./TestScript-hospitalnotification-receive-staa.md) | R2 | Receive: Start hospital stay - acute ambulant | STAA |   |
| [SLHJ-emer](./TestScript-hospitalnotification-receive-slhj-emer.md) | R6 | Receive: End hospital stay - patient completed to home/primary sector | SLHJ | STAA |
| [MORS-emer](./TestScript-hospitalnotification-receive-mors-emer.md) | R7 | Receive: Deceased - deceased during acute ambulant | MORS | STAA |
| **Inpatient** |   |   |   |   |
| [RE_STIN](./TestScript-hospitalnotification-receive-re-stin.md) | R.CORR | Receive: Update Start hospital stay | RE_STIN | STIN |
| [RE_STOR](./TestScript-hospitalnotification-receive-re-stor.md) | R.CORR | Receive: Update Start leave | RE_STOR | STIN, STOR |
| [RE_SLOR](./TestScript-hospitalnotification-receive-re-slor.md) | R.CORR | Receive: Update End leave | RE_SLOR | STIN, STOR, SLOR |
| [RE_SLHJ-imp](./TestScript-hospitalnotification-receive-re-slhj-imp.md) | R.CORR | Receive: Update End hospital stay – patient completed to home/primary sector | RE_SLHJ | STIN, SLHJ |
| [RE_MORS](./TestScript-hospitalnotification-receive-re-mors.md) | R.CORR | Receive: Update Deceased - is dead at arrival to the hospital | RE_MORS | MORS |
| [RE_MORS-imp](./TestScript-hospitalnotification-receive-re-mors-imp.md) | R.CORR | Receive: Update Deceased - deceased during hospital stay | RE_MORS | STIN, MORS |
| [RE_MORS-STOR](./TestScript-hospitalnotification-receive-re-mors-stor.md) | R.CORR | Receive: Update Deceased - deceased during a period of leave | RE_MORS | STIN, STOR, MORS |
| **Emergency** |   |   |   |   |
| [RE_STAA](./TestScript-hospitalnotification-receive-re-staa.md) | R.CORR | Receive: Update Start hospital stay - acute ambulant | RE_STAA | STAA |
| [RE_SLHJ-emer](./TestScript-hospitalnotification-receive-re-slhj-emer.md) | R.CORR | Receive: Update End hospital stay – patient completed to home/primary sector | RE_SLHJ | STAA, SLHJ |
| [RE_MORS-emer](./TestScript-hospitalnotification-receive-re-mors-emer.md) | R.CORR | Receive: Update Deceased - deceased during acute ambulant | RE_MORS | STAA, MORS |
| **Inpatient** |   |   |   |   |
| [AN_STIN](./TestScript-hospitalnotification-receive-an-stin.md) | R.CANC | Receive: Cancellation Start hospital stay | AN_STIN | STIN |
| [AN_STOR](./TestScript-hospitalnotification-receive-an-stor.md) | R.CANC | Receive: Cancellation Start leave | AN_STOR | STIN, STOR |
| [AN_SLOR](./TestScript-hospitalnotification-receive-an-slor.md) | R.CANC | Receive: Cancellation End leave | AN_SLOR | STIN, STOR, SLOR |
| [AN_SLHJ-imp](./TestScript-hospitalnotification-receive-an-slhj-imp.md) | R.CANC | Receive: Cancellation End hospital stay – patient completed to home/primary sector | AN_SLHJ | STIN, SLHJ |
| [AN_MORS](./TestScript-hospitalnotification-receive-an-mors.md) | R.CANC | Receive: Cancellation Deceased - is dead at arrival to the hospital | AN_MORS | MORS |
| [AN_MORS-imp](./TestScript-hospitalnotification-receive-an-mors-imp.md) | R.CANC | Receive: Cancellation Deceased - deceased during hospital stay | AN_MORS | STIN, MORS |
| [AN_MORS-STOR](./TestScript-hospitalnotification-receive-an-mors-stor.md) | R.CANC | Receive: Cancellation Deceased - deceased during a period of leave | AN_MORS | STIN, STOR, MORS |
| **Emergency** |   |   |   |   |
| [AN_STAA](./TestScript-hospitalnotification-receive-an-staa.md) | R.CANC | Receive: Cancellation Start hospital stay - acute ambulant | AN_STAA | STAA |
| [AN_SLHJ-emer](./TestScript-hospitalnotification-receive-an-slhj-emer.md) | R.CANC | Receive: Cancellation End hospital stay – patient completed to home/primary sector | AN_STOR | STAA, SLHJ |
| [AN_MORS-emer](./TestScript-hospitalnotification-receive-an-mors-emer.md) | R.CANC | Receive: Cancellation Deceased - deceased during acute ambulant | AN_MORS | STAA, MORS |

#### Patient Flow

[Test scripts for test of the recieving patient flows, can be found here in TouchStone.](https://touchstone.aegis.net/touchstone/testdefinitions?selectedTestGrp=/FHIRSandbox/MedCom/HospitalNotification/v300-receive/PatientFlows&activeOnly=false&contentEntry=TEST_SCRIPTS)

| | | |
| :--- | :--- | :--- |
| **Inpatient** |   |   |
| [PF-receive-imp-01](./TestScript-hospitalnotification-PF-receive-imp-01.md) | Receive: Patient is admitted, patient is registered as being on leave, patient returns from leave, patient is discharged | STIN, STOR, SLOR, SLHJ |
| [PF-receive-imp-02](./TestScript-hospitalnotification-PF-receive-imp-02.md) | Receive: Patient is admitted, patient is registered as being on leave, patient doesn't return from leave, patient is discharged | STIN, STOR, SLHJ |
| [PF-receive-imp-03](./TestScript-hospitalnotification-PF-receive-imp-03.md) | Receive: Patient is admitted, patient is registered as being on leave, patient returns from leave, patient is registered as dead | STIN, STOR, SLOR, MORS |
| [PF-receive-imp-04](./TestScript-hospitalnotification-PF-receive-imp-04.md) | Receive: Patient is admitted, 'patient is registered as being on leave, patient returns from leave', ' to ' x 2 | STIN, STOR, SLOR, STOR, SLOR |
| [PF-receive-imp-05](./TestScript-hospitalnotification-PF-receive-imp-05.md) | Receive: Patient is admitted, message is corrected due to incorrect hospital department | STIN, RE_STIN |
| [PF-receive-imp-06](./TestScript-hospitalnotification-PF-receive-imp-06.md) | Receive: Patient is admitted, message is corrected due to incorrect time of admission | STIN, RE_STIN |
| **Emergency** |   |   |
| [PF-receive-emer-01](./TestScript-hospitalnotification-PF-receive-emer-01.md) | Receive: Patient is admitted, message is corrected due to incorrect hospital department | STAA, RE_STAA |
| [PF-receive-emer-02](./TestScript-hospitalnotification-PF-receive-emer-02.md) | Receive: Patient is admitted, message is corrected due to incorrect time of admission | STAA, RE_STAA |
| **Emergency/Inpatient** |   |   |
| [PF-receive-emer-imp-01](./TestScript-hospitalnotification-PF-receive-emer-imp-01.md) | Receive: Patient is admitted as emergency, patient is admitted as inpatient, patient is discharged | STAA, STIN, SLHJ |
| **Technical** |   |   |
| [PF-receive-tec-01](./TestScript-hospitalnotification-PF-receive-tec-01.md) | Receive dublicate: Patient is admitted, doesn't get acknowledged, patient is admitted | STIN, STIN |
| [PF-receive-tec-02](./TestScript-hospitalnotification-PF-receive-tec-02.md) | Receive: Receive cancellation of admit patient: Patient is admitted, correction of admit patient and cancellation admit patient | STIN, RE_STIN, AN_STIN |
| [PF-receive-tec-03](./TestScript-hospitalnotification-PF-receive-tec-03.md) | Receive: Messages received in wrong order: Patient is admitted as emergency, patient is discharged, patient is admitted as inpatient. | STAA, SLHJ, STIN |
| [PF-receive-tec-04](./TestScript-hospitalnotification-PF-receive-tec-04.md) | Receive: Receive a message with different timezones (+01:00 and +02:00): Patient is admitted in one timezone, patient is discharged in a different timezone. | STIN, SLHJ |
| [PF-receive-tec-05](./TestScript-hospitalnotification-PF-receive-tec-05.md) | Receive: Receive a message on the 29th of February 2024 (leap year): Patient is admitted on the date of leap year | STIN |
| [PF-receive-tec-06](./TestScript-hospitalnotification-PF-receive-tec-06.md) | Receive: Receive a message where the serviceprovider is different from the sender: Patient is admitted | STIN |

1. In this flow it is allowed to add a SLOR-message between STOR and SLHJ. In case the system does so, please skip this test script. [↩](#fnref:1)

