# a6cebbce-2b7a-478f-aefd-57305f3b05c1 - HospitalNotification Testscripts v3.0.3

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **a6cebbce-2b7a-478f-aefd-57305f3b05c1**

## Bundle: a6cebbce-2b7a-478f-aefd-57305f3b05c1



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "a6cebbce-2b7a-478f-aefd-57305f3b05c1",
  "meta" : {
    "profile" : ["http://medcomfhir.dk/ig/hospitalnotification/StructureDefinition/medcom-hospitalNotification-message"]
  },
  "type" : "message",
  "timestamp" : "2026-03-03T14:00:12+01:00",
  "entry" : [{
    "fullUrl" : "https://medcomfhir.dk/ig/hospitalnotification/MessageHeader/53a5e12e-3f15-4db9-80e2-a38957a2006b",
    "resource" : {
      "resourceType" : "MessageHeader",
      "id" : "53a5e12e-3f15-4db9-80e2-a38957a2006b",
      "meta" : {
        "profile" : ["http://medcomfhir.dk/ig/hospitalnotification/StructureDefinition/medcom-hospitalNotification-messageHeader"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MessageHeader_53a5e12e-3f15-4db9-80e2-a38957a2006b\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MessageHeader 53a5e12e-3f15-4db9-80e2-a38957a2006b</b></p><a name=\"53a5e12e-3f15-4db9-80e2-a38957a2006b\"> </a><a name=\"hc53a5e12e-3f15-4db9-80e2-a38957a2006b\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-medcom-hospitalNotification-messageHeader.html\">MedComHospitalNotificationMessageHeader</a></p></div><p><b>event</b>: <a href=\"http://medcomfhir.dk/ig/terminology/1.5.0/CodeSystem-medcom-messaging-eventCodes.html#medcom-messaging-eventCodes-hospital-notification-message\">MedComMessagingEventCodes: hospital-notification-message</a> (Hospital Notification Message)</p><h3>Destinations</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Extension</b></td><td><b>Endpoint</b></td><td><b>Receiver</b></td></tr><tr><td style=\"display: none\">*</td><td/><td><a href=\"https://sor2.sum.dsdn.dk/#id=953741000016009\">https://sor2.sum.dsdn.dk/#id=953741000016009</a></td><td><a href=\"Organization-a1eb00df-26bd-4784-a326-1f5a17210c67.html\">Organization Plejecenter Herlev</a></td></tr></table><p><b>sender</b>: <a href=\"Organization-107f3635-87b0-416f-959c-447b5221dfcc.html\">Organization Hjerteafdelingen på Herlev og Gentofte hospital</a></p><h3>Sources</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Endpoint</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"https://sor2.sum.dsdn.dk/#id=265161000016000\">https://sor2.sum.dsdn.dk/#id=265161000016000</a></td></tr></table><p><b>focus</b>: <a href=\"Encounter-0d07998f-2811-4e0f-97e3-ae1dbc6e7977.html\">Encounter: extension = 2026-03-03 14:00:10+0100 --&gt; (ongoing); status = onleave; class = inpatient encounter (ActCode#IMP); period = 2026-03-01 12:00:00+0100 --&gt; (ongoing)</a></p></div>"
      },
      "eventCoding" : {
        "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-messaging-eventCodes",
        "code" : "hospital-notification-message"
      },
      "destination" : [{
        "extension" : [{
          "url" : "http://medcomfhir.dk/ig/messaging/StructureDefinition/medcom-messaging-destinationUseExtension",
          "valueCoding" : {
            "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-messaging-destinationUse",
            "code" : "primary"
          }
        }],
        "endpoint" : "https://sor2.sum.dsdn.dk/#id=953741000016009",
        "receiver" : {
          "reference" : "Organization/a1eb00df-26bd-4784-a326-1f5a17210c67"
        }
      }],
      "sender" : {
        "reference" : "Organization/107f3635-87b0-416f-959c-447b5221dfcc"
      },
      "source" : {
        "endpoint" : "https://sor2.sum.dsdn.dk/#id=265161000016000"
      },
      "focus" : [{
        "reference" : "Encounter/0d07998f-2811-4e0f-97e3-ae1dbc6e7977"
      }]
    }
  },
  {
    "fullUrl" : "https://medcomfhir.dk/ig/hospitalnotification/Patient/378d5dc6-0bfc-457b-9cd5-6cf32243dc89",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "378d5dc6-0bfc-457b-9cd5-6cf32243dc89",
      "meta" : {
        "profile" : ["http://medcomfhir.dk/ig/core/StructureDefinition/medcom-core-patient"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_378d5dc6-0bfc-457b-9cd5-6cf32243dc89\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient 378d5dc6-0bfc-457b-9cd5-6cf32243dc89</b></p><a name=\"378d5dc6-0bfc-457b-9cd5-6cf32243dc89\"> </a><a name=\"hc378d5dc6-0bfc-457b-9cd5-6cf32243dc89\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://medcomfhir.dk/ig/core/2.3.0/StructureDefinition-medcom-core-patient.html\">MedComCorePatient</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Elmer (official) (no stated gender), DoB Unknown ( urn:oid:1.2.208.176.1.2#DkCoreDanishCivilRegistrationSystem#2509479989)</p><hr/></div>"
      },
      "identifier" : [{
        "system" : "urn:oid:1.2.208.176.1.2",
        "value" : "2509479989"
      }],
      "name" : [{
        "use" : "official",
        "family" : "Elmer"
      }]
    }
  },
  {
    "fullUrl" : "https://medcomfhir.dk/ig/hospitalnotification/Encounter/0d07998f-2811-4e0f-97e3-ae1dbc6e7977",
    "resource" : {
      "resourceType" : "Encounter",
      "id" : "0d07998f-2811-4e0f-97e3-ae1dbc6e7977",
      "meta" : {
        "profile" : ["http://medcomfhir.dk/ig/hospitalnotification/StructureDefinition/medcom-hospitalNotification-encounter"]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Encounter_0d07998f-2811-4e0f-97e3-ae1dbc6e7977\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Encounter 0d07998f-2811-4e0f-97e3-ae1dbc6e7977</b></p><a name=\"0d07998f-2811-4e0f-97e3-ae1dbc6e7977\"> </a><a name=\"hc0d07998f-2811-4e0f-97e3-ae1dbc6e7977\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-medcom-hospitalNotification-encounter.html\">MedComHospitalNotificationEncounter</a></p></div><p><b>MedComHospitalNotificationLeavePeriodExtension</b>: 2026-03-03 14:00:10+0100 --&gt; (ongoing)</p><p><b>status</b>: On Leave</p><p><b>class</b>: <a href=\"http://terminology.hl7.org/7.3.0/CodeSystem-v3-ActCode.html#v3-ActCode-IMP\">ActCode: IMP</a> (inpatient encounter)</p><p><b>subject</b>: <a href=\"Patient-378d5dc6-0bfc-457b-9cd5-6cf32243dc89.html\">Elmer (official) (no stated gender), DoB Unknown ( urn:oid:1.2.208.176.1.2#DkCoreDanishCivilRegistrationSystem#2509479989)</a></p><p><b>episodeOfCare</b>: Identifier: <code>https://sor2.sum.dsdn.dk/#id=265161000016000</code>/04675bbd-c540-4545-924c-1fa79b64535c</p><p><b>period</b>: 2026-03-01 12:00:00+0100 --&gt; (ongoing)</p><p><b>serviceProvider</b>: <a href=\"Organization-107f3635-87b0-416f-959c-447b5221dfcc.html\">Organization Hjerteafdelingen på Herlev og Gentofte hospital</a></p></div>"
      },
      "extension" : [{
        "url" : "http://medcomfhir.dk/ig/hospitalnotification/StructureDefinition/medcom-hospitalnotifiation-leave-period-extension",
        "valuePeriod" : {
          "start" : "2026-03-03T14:00:10+01:00"
        }
      }],
      "status" : "onleave",
      "class" : {
        "system" : "http://terminology.hl7.org/CodeSystem/v3-ActCode",
        "code" : "IMP"
      },
      "subject" : {
        "reference" : "Patient/378d5dc6-0bfc-457b-9cd5-6cf32243dc89"
      },
      "episodeOfCare" : [{
        "identifier" : {
          "system" : "https://sor2.sum.dsdn.dk/#id=265161000016000",
          "value" : "04675bbd-c540-4545-924c-1fa79b64535c"
        }
      }],
      "period" : {
        "start" : "2026-03-01T12:00:00+01:00"
      },
      "serviceProvider" : {
        "reference" : "Organization/107f3635-87b0-416f-959c-447b5221dfcc"
      }
    }
  },
  {
    "fullUrl" : "https://medcomfhir.dk/ig/hospitalnotification/Organization/a1eb00df-26bd-4784-a326-1f5a17210c67",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "a1eb00df-26bd-4784-a326-1f5a17210c67",
      "meta" : {
        "profile" : ["http://medcomfhir.dk/ig/messaging/StructureDefinition/medcom-messaging-organization"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_a1eb00df-26bd-4784-a326-1f5a17210c67\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization a1eb00df-26bd-4784-a326-1f5a17210c67</b></p><a name=\"a1eb00df-26bd-4784-a326-1f5a17210c67\"> </a><a name=\"hca1eb00df-26bd-4784-a326-1f5a17210c67\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://medcomfhir.dk/ig/messaging/2.1.0/StructureDefinition-medcom-messaging-organization.html\">MedComMessagingOrganization</a></p></div><p><b>identifier</b>: <code>https://www.gs1.org/gln</code>/5790001348120, <code>urn:oid:1.2.208.176.1.1</code>/953741000016009</p><p><b>name</b>: Plejecenter Herlev</p></div>"
      },
      "identifier" : [{
        "system" : "https://www.gs1.org/gln",
        "value" : "5790001348120"
      },
      {
        "system" : "urn:oid:1.2.208.176.1.1",
        "value" : "953741000016009"
      }],
      "name" : "Plejecenter Herlev"
    }
  },
  {
    "fullUrl" : "https://medcomfhir.dk/ig/hospitalnotification/Organization/107f3635-87b0-416f-959c-447b5221dfcc",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "107f3635-87b0-416f-959c-447b5221dfcc",
      "meta" : {
        "profile" : ["http://medcomfhir.dk/ig/messaging/StructureDefinition/medcom-messaging-organization"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_107f3635-87b0-416f-959c-447b5221dfcc\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization 107f3635-87b0-416f-959c-447b5221dfcc</b></p><a name=\"107f3635-87b0-416f-959c-447b5221dfcc\"> </a><a name=\"hc107f3635-87b0-416f-959c-447b5221dfcc\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://medcomfhir.dk/ig/messaging/2.1.0/StructureDefinition-medcom-messaging-organization.html\">MedComMessagingOrganization</a></p></div><p><b>identifier</b>: <code>https://www.gs1.org/gln</code>/5790000209354, <code>urn:oid:1.2.208.176.1.1</code>/265161000016000</p><p><b>name</b>: Hjerteafdelingen på Herlev og Gentofte hospital</p></div>"
      },
      "identifier" : [{
        "system" : "https://www.gs1.org/gln",
        "value" : "5790000209354"
      },
      {
        "system" : "urn:oid:1.2.208.176.1.1",
        "value" : "265161000016000"
      }],
      "name" : "Hjerteafdelingen på Herlev og Gentofte hospital"
    }
  },
  {
    "fullUrl" : "https://medcomfhir.dk/ig/hospitalnotification/Provenance/fbccbea9-bce4-4590-bd0c-e9e4c4f13b06",
    "resource" : {
      "resourceType" : "Provenance",
      "id" : "fbccbea9-bce4-4590-bd0c-e9e4c4f13b06",
      "meta" : {
        "profile" : ["http://medcomfhir.dk/ig/messaging/StructureDefinition/medcom-messaging-provenance"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Provenance_fbccbea9-bce4-4590-bd0c-e9e4c4f13b06\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Provenance fbccbea9-bce4-4590-bd0c-e9e4c4f13b06</b></p><a name=\"fbccbea9-bce4-4590-bd0c-e9e4c4f13b06\"> </a><a name=\"hcfbccbea9-bce4-4590-bd0c-e9e4c4f13b06\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://medcomfhir.dk/ig/messaging/2.1.0/StructureDefinition-medcom-messaging-provenance.html\">MedComMessagingProvenance</a></p></div><p>Provenance for <a href=\"MessageHeader/b9b4818e-02de-4cc4-b418-d20cbc399006\">MessageHeader/b9b4818e-02de-4cc4-b418-d20cbc399006</a></p><p>Summary</p><table class=\"grid\"><tr><td>Occurrence</td><td>2026-03-01 12:00:02+0100</td></tr><tr><td>Recorded</td><td>2026-03-01 12:00:02+0100</td></tr><tr><td>Activity</td><td><span title=\"Codes:{http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-messaging-activityCodes admit-inpatient}\">Start hospital stay - admitted</span></td></tr></table><p><b>Agents</b></p><table class=\"grid\"><tr><td><b>who</b></td></tr><tr><td><a href=\"Organization-107f3635-87b0-416f-959c-447b5221dfcc.html\">Organization Hjerteafdelingen på Herlev og Gentofte hospital</a></td></tr></table></div>"
      },
      "target" : [{
        "reference" : "MessageHeader/b9b4818e-02de-4cc4-b418-d20cbc399006"
      }],
      "occurredDateTime" : "2026-03-01T12:00:02+01:00",
      "recorded" : "2026-03-01T12:00:02+01:00",
      "activity" : {
        "coding" : [{
          "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-messaging-activityCodes",
          "code" : "admit-inpatient"
        }]
      },
      "agent" : [{
        "who" : {
          "reference" : "Organization/107f3635-87b0-416f-959c-447b5221dfcc"
        }
      }]
    }
  },
  {
    "fullUrl" : "https://medcomfhir.dk/ig/hospitalnotification/Provenance/f8e43fe8-4db9-4168-b04d-bd9e94a099d8",
    "resource" : {
      "resourceType" : "Provenance",
      "id" : "f8e43fe8-4db9-4168-b04d-bd9e94a099d8",
      "meta" : {
        "profile" : ["http://medcomfhir.dk/ig/messaging/StructureDefinition/medcom-messaging-provenance"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Provenance_f8e43fe8-4db9-4168-b04d-bd9e94a099d8\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Provenance f8e43fe8-4db9-4168-b04d-bd9e94a099d8</b></p><a name=\"f8e43fe8-4db9-4168-b04d-bd9e94a099d8\"> </a><a name=\"hcf8e43fe8-4db9-4168-b04d-bd9e94a099d8\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://medcomfhir.dk/ig/messaging/2.1.0/StructureDefinition-medcom-messaging-provenance.html\">MedComMessagingProvenance</a></p></div><p>Provenance for <a href=\"MessageHeader-53a5e12e-3f15-4db9-80e2-a38957a2006b.html\">MessageHeader: event[x] = Hospital Notification Message (MedComMessagingEventCodes#hospital-notification-message)</a></p><p>Summary</p><table class=\"grid\"><tr><td>Occurrence</td><td>2026-03-03 14:00:12+0100</td></tr><tr><td>Recorded</td><td>2026-03-03 14:00:12+0100</td></tr><tr><td>Activity</td><td><span title=\"Codes:{http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-messaging-activityCodes start-leave-inpatient}\">Start leave</span></td></tr></table><p><b>Agents</b></p><table class=\"grid\"><tr><td><b>who</b></td></tr><tr><td><a href=\"Organization-107f3635-87b0-416f-959c-447b5221dfcc.html\">Organization Hjerteafdelingen på Herlev og Gentofte hospital</a></td></tr></table></div>"
      },
      "target" : [{
        "reference" : "MessageHeader/53a5e12e-3f15-4db9-80e2-a38957a2006b"
      }],
      "occurredDateTime" : "2026-03-03T14:00:12+01:00",
      "recorded" : "2026-03-03T14:00:12+01:00",
      "activity" : {
        "coding" : [{
          "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-messaging-activityCodes",
          "code" : "start-leave-inpatient"
        }]
      },
      "agent" : [{
        "who" : {
          "reference" : "Organization/107f3635-87b0-416f-959c-447b5221dfcc"
        }
      }],
      "entity" : [{
        "role" : "revision",
        "what" : {
          "reference" : "MessageHeader/b9b4818e-02de-4cc4-b418-d20cbc399006"
        }
      }]
    }
  }]
}

```
