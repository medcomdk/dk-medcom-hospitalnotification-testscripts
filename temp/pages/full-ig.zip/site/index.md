# Home - HospitalNotification Testscripts v3.0.3

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://medcomfhir.dk/ig/hospitalnotificationtestscripts/ImplementationGuide/medcom.fhir.dk.hospitalnotificationtestscripts | *Version*:3.0.3 |
| Active as of 2026-09-15 | *Computable Name*:HospitalNotificationTestscripts |

### Background

This Implementation Guide (IG) has two purposes: 1) to present test scripts for sending and receiving HospitalNotifications v. 3.0.0 are included. 2) to present test examples used in the testprotocol for receiving HospitalNotifications.

Both test scripts and test examples are developed by MedCom. For more information, please click on the tabs above.

#### Relevant information

The following pages might be of interest when implementing HospitalNotification:

* [GitHub-pages for HospitalNotification](https://medcomdk.github.io/dk-medcom-hospitalnotification) 
* [Testprotocol for sending and receiving HospitalNotification](https://medcomdk.github.io/dk-medcom-hospitalnotification/#2-test-and-certification)
 
* [Implementation Guide for HospitalNotification v. 3.0.0](https://medcomfhir.dk/ig/hospitalnotification/3.0.0)
* [Governance for MedCom FHIR messaging](https://medcomdk.github.io/MedComLandingPage/)

### Governance

A description of [governance concerning change management and versioning of MedComs FHIR artefacts, can be found on here](https://medcomdk.github.io/MedComLandingPage/#4-change-management-and-versioning).

#### Download

Content in this IG can be downloaded under [Download](downloads.md). The download includes both test scripts and test examples. It is also possible to download each artifact, on the individual page.

#### Quality Assurance Report

In the Quality Assurance report (QA-report) for this IG there are some errors and warnings. An instance of the errors are: **Unable to resolve resource with reference '/FHIRSandbox/MedCom/HospitalNotificationTMS/HospitalNotification-fixture-SLOR.xml** and **Unable to resolve resource with reference 'http://medcomfhir.dk/ig/hospitalnotification/StructureDefinition/medcom-hospitalNotification-message'**. The errors occur when creating a test script, as the fixture and profile are not reachable in the IG. However, they are reachable from TouchStone, why it is of less concern. For vendors who uses the test scripts locally should be aware of the error and e.g. create the fixtures and define the profile locally.

#### Contact

[MedCom](https://www.medcom.dk/) is responsible for this IG.

If you have any questions, please contact [fhir@medcom.dk](mailto:fhir@medcom.dk) or write to MedCom’s stream in [Zulip](https://chat.fhir.org/#narrow/stream/315677-denmark.2Fmedcom.2FFHIRimplementationErfaGroup).



## Resource Content

```json
{
  "resourceType" : "ImplementationGuide",
  "id" : "medcom.fhir.dk.hospitalnotificationtestscripts",
  "url" : "http://medcomfhir.dk/ig/hospitalnotificationtestscripts/ImplementationGuide/medcom.fhir.dk.hospitalnotificationtestscripts",
  "version" : "3.0.3",
  "name" : "HospitalNotificationTestscripts",
  "title" : "HospitalNotification Testscripts",
  "status" : "active",
  "date" : "2026-09-15T13:08:01+02:00",
  "contact" : [{
    "name" : "MedCom",
    "telecom" : [{
      "system" : "email",
      "value" : "mailto:fhir@medcom.dk"
    }]
  }],
  "description" : "Testscripts for HospitalNotification v. 3.0.0",
  "packageId" : "medcom.fhir.dk.hospitalnotificationtestscripts",
  "license" : "CC0-1.0",
  "fhirVersion" : ["4.0.1"],
  "dependsOn" : [{
    "id" : "hl7tx",
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-dependency-comment",
      "valueMarkdown" : "Automatically added as a dependency - all IGs depend on HL7 Terminology"
    }],
    "uri" : "http://terminology.hl7.org/ImplementationGuide/hl7.terminology",
    "packageId" : "hl7.terminology.r4",
    "version" : "7.3.0"
  },
  {
    "id" : "hl7ext",
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-dependency-comment",
      "valueMarkdown" : "Automatically added as a dependency - all IGs depend on the HL7 Extension Pack"
    }],
    "uri" : "http://hl7.org/fhir/extensions/ImplementationGuide/hl7.fhir.uv.extensions",
    "packageId" : "hl7.fhir.uv.extensions.r4",
    "version" : "5.3.0"
  },
  {
    "id" : "medcom_fhir_dk_hospitalnotification",
    "uri" : "http://medcomfhir.dk/ig/hospitalnotification/ImplementationGuide/medcom.fhir.dk.hospitalnotification",
    "packageId" : "medcom.fhir.dk.hospitalnotification",
    "version" : "3.0.1"
  }],
  "definition" : {
    "extension" : [{
      "extension" : [{
        "url" : "code",
        "valueString" : "copyrightyear"
      },
      {
        "url" : "value",
        "valueString" : "2020+"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "releaselabel"
      },
      {
        "url" : "value",
        "valueString" : "release"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-publisher"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-contact"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "show-inherited-invariants"
      },
      {
        "url" : "value",
        "valueString" : "false"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "autoload-resources"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-liquid"
      },
      {
        "url" : "value",
        "valueString" : "template/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-liquid"
      },
      {
        "url" : "value",
        "valueString" : "input/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-qa"
      },
      {
        "url" : "value",
        "valueString" : "temp/qa"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-temp"
      },
      {
        "url" : "value",
        "valueString" : "temp/pages"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-output"
      },
      {
        "url" : "value",
        "valueString" : "output"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-suppressed-warnings"
      },
      {
        "url" : "value",
        "valueString" : "input/ignoreWarnings.txt"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-history"
      },
      {
        "url" : "value",
        "valueString" : "http://medcomfhir.dk/ig/hospitalnotificationtestscripts/history.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "template-html"
      },
      {
        "url" : "value",
        "valueString" : "template-page.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "template-md"
      },
      {
        "url" : "value",
        "valueString" : "template-page-md.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-context"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-copyright"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-jurisdiction"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-license"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-version"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-wg"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "active-tables"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "fmm-definition"
      },
      {
        "url" : "value",
        "valueString" : "http://hl7.org/fhir/versions.html#maturity"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "propagate-status"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "excludelogbinaryformat"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "tabbed-snapshots"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-internal-dependency",
      "valueCode" : "hl7.fhir.uv.tools.r4#1.1.2"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "copyrightyear"
      },
      {
        "url" : "value",
        "valueString" : "2020+"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "releaselabel"
      },
      {
        "url" : "value",
        "valueString" : "release"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-publisher"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-contact"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "show-inherited-invariants"
      },
      {
        "url" : "value",
        "valueString" : "false"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "autoload-resources"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-liquid"
      },
      {
        "url" : "value",
        "valueString" : "template/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-liquid"
      },
      {
        "url" : "value",
        "valueString" : "input/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-qa"
      },
      {
        "url" : "value",
        "valueString" : "temp/qa"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-temp"
      },
      {
        "url" : "value",
        "valueString" : "temp/pages"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-output"
      },
      {
        "url" : "value",
        "valueString" : "output"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-suppressed-warnings"
      },
      {
        "url" : "value",
        "valueString" : "input/ignoreWarnings.txt"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-history"
      },
      {
        "url" : "value",
        "valueString" : "http://medcomfhir.dk/ig/hospitalnotificationtestscripts/history.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "template-html"
      },
      {
        "url" : "value",
        "valueString" : "template-page.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "template-md"
      },
      {
        "url" : "value",
        "valueString" : "template-page-md.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-context"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-copyright"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-jurisdiction"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-license"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-version"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-wg"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "active-tables"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "fmm-definition"
      },
      {
        "url" : "value",
        "valueString" : "http://hl7.org/fhir/versions.html#maturity"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "propagate-status"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "excludelogbinaryformat"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "tabbed-snapshots"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    }],
    "resource" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-172992fd-7910-486b-9039-ae58de0786c8.html"
      }],
      "reference" : {
        "reference" : "Bundle/172992fd-7910-486b-9039-ae58de0786c8"
      },
      "name" : "172992fd-7910-486b-9039-ae58de0786c8",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-1a505c7a-f790-4cb7-9d68-ee8993e84736.html"
      }],
      "reference" : {
        "reference" : "Bundle/1a505c7a-f790-4cb7-9d68-ee8993e84736"
      },
      "name" : "1a505c7a-f790-4cb7-9d68-ee8993e84736",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-1acdc074-1793-4651-831d-d45383de88d7.html"
      }],
      "reference" : {
        "reference" : "Bundle/1acdc074-1793-4651-831d-d45383de88d7"
      },
      "name" : "1acdc074-1793-4651-831d-d45383de88d7",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-2f7168e9-9c1f-4103-a30a-e5c4acf05c45.html"
      }],
      "reference" : {
        "reference" : "Bundle/2f7168e9-9c1f-4103-a30a-e5c4acf05c45"
      },
      "name" : "2f7168e9-9c1f-4103-a30a-e5c4acf05c45",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-36c3dd0e-7212-4e97-b857-507f91a36ee5.html"
      }],
      "reference" : {
        "reference" : "Bundle/36c3dd0e-7212-4e97-b857-507f91a36ee5"
      },
      "name" : "36c3dd0e-7212-4e97-b857-507f91a36ee5",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-373df375-0eee-4d48-9fee-2381991d55ba.html"
      }],
      "reference" : {
        "reference" : "Bundle/373df375-0eee-4d48-9fee-2381991d55ba"
      },
      "name" : "373df375-0eee-4d48-9fee-2381991d55ba",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-37dfb04f-86c6-4d86-96a5-f2334c1af711.html"
      }],
      "reference" : {
        "reference" : "Bundle/37dfb04f-86c6-4d86-96a5-f2334c1af711"
      },
      "name" : "37dfb04f-86c6-4d86-96a5-f2334c1af711",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-650a355e-438e-41c7-a7f1-0e3e0df18e16.html"
      }],
      "reference" : {
        "reference" : "Bundle/650a355e-438e-41c7-a7f1-0e3e0df18e16"
      },
      "name" : "650a355e-438e-41c7-a7f1-0e3e0df18e16",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-69b98015-a0af-4e09-99bf-85e08a62479c.html"
      }],
      "reference" : {
        "reference" : "Bundle/69b98015-a0af-4e09-99bf-85e08a62479c"
      },
      "name" : "69b98015-a0af-4e09-99bf-85e08a62479c",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-7502c124-03b0-4347-8edf-424b0c978627.html"
      }],
      "reference" : {
        "reference" : "Bundle/7502c124-03b0-4347-8edf-424b0c978627"
      },
      "name" : "7502c124-03b0-4347-8edf-424b0c978627",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-7b380ba1-6d36-4c59-9878-1d9875011a6b.html"
      }],
      "reference" : {
        "reference" : "Bundle/7b380ba1-6d36-4c59-9878-1d9875011a6b"
      },
      "name" : "7b380ba1-6d36-4c59-9878-1d9875011a6b",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-857fc416-31c1-4724-9a2e-da3888aa5562.html"
      }],
      "reference" : {
        "reference" : "Bundle/857fc416-31c1-4724-9a2e-da3888aa5562"
      },
      "name" : "857fc416-31c1-4724-9a2e-da3888aa5562",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-9008049a-98cb-4a0e-82a0-89f1a8aca70d.html"
      }],
      "reference" : {
        "reference" : "Bundle/9008049a-98cb-4a0e-82a0-89f1a8aca70d"
      },
      "name" : "9008049a-98cb-4a0e-82a0-89f1a8aca70d",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-9011f888-3bcc-46d6-848b-297aca060e7f.html"
      }],
      "reference" : {
        "reference" : "Bundle/9011f888-3bcc-46d6-848b-297aca060e7f"
      },
      "name" : "9011f888-3bcc-46d6-848b-297aca060e7f",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-909f89db-2f6c-458d-a3e6-bda0c1603194.html"
      }],
      "reference" : {
        "reference" : "Bundle/909f89db-2f6c-458d-a3e6-bda0c1603194"
      },
      "name" : "909f89db-2f6c-458d-a3e6-bda0c1603194",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-912b06fc-5530-444b-abe1-ea06eee61cce.html"
      }],
      "reference" : {
        "reference" : "Bundle/912b06fc-5530-444b-abe1-ea06eee61cce"
      },
      "name" : "912b06fc-5530-444b-abe1-ea06eee61cce",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-920d2d1e-8c21-462c-9917-10b18eefba3f.html"
      }],
      "reference" : {
        "reference" : "Bundle/920d2d1e-8c21-462c-9917-10b18eefba3f"
      },
      "name" : "920d2d1e-8c21-462c-9917-10b18eefba3f",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-9a1b6304-9a5e-41d4-9460-442cc11d4d6c.html"
      }],
      "reference" : {
        "reference" : "Bundle/9a1b6304-9a5e-41d4-9460-442cc11d4d6c"
      },
      "name" : "9a1b6304-9a5e-41d4-9460-442cc11d4d6c",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-9e7da343-d585-4cca-b3bb-e06ea27ae62a.html"
      }],
      "reference" : {
        "reference" : "Bundle/9e7da343-d585-4cca-b3bb-e06ea27ae62a"
      },
      "name" : "9e7da343-d585-4cca-b3bb-e06ea27ae62a",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-a0536ce3-9687-4c3f-a753-47d37dc8cb04.html"
      }],
      "reference" : {
        "reference" : "Bundle/a0536ce3-9687-4c3f-a753-47d37dc8cb04"
      },
      "name" : "a0536ce3-9687-4c3f-a753-47d37dc8cb04",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-a6cebbce-2b7a-478f-aefd-57305f3b05c1.html"
      }],
      "reference" : {
        "reference" : "Bundle/a6cebbce-2b7a-478f-aefd-57305f3b05c1"
      },
      "name" : "a6cebbce-2b7a-478f-aefd-57305f3b05c1",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-b40c8da9-81b5-473b-898e-c8536cb36d34.html"
      }],
      "reference" : {
        "reference" : "Bundle/b40c8da9-81b5-473b-898e-c8536cb36d34"
      },
      "name" : "b40c8da9-81b5-473b-898e-c8536cb36d34",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-b4625f1e-ba87-4f11-95b2-9f1923a006ec.html"
      }],
      "reference" : {
        "reference" : "Bundle/b4625f1e-ba87-4f11-95b2-9f1923a006ec"
      },
      "name" : "b4625f1e-ba87-4f11-95b2-9f1923a006ec",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-b9c4da96-8f0e-48b8-bf1d-87899f663d01.html"
      }],
      "reference" : {
        "reference" : "Bundle/b9c4da96-8f0e-48b8-bf1d-87899f663d01"
      },
      "name" : "b9c4da96-8f0e-48b8-bf1d-87899f663d01",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-bec4ba50-a0ed-4d98-a618-78ec3c5ed4c3.html"
      }],
      "reference" : {
        "reference" : "Bundle/bec4ba50-a0ed-4d98-a618-78ec3c5ed4c3"
      },
      "name" : "bec4ba50-a0ed-4d98-a618-78ec3c5ed4c3",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-c5a3b081-fbcc-4d47-bc26-ef509f9bbadb.html"
      }],
      "reference" : {
        "reference" : "Bundle/c5a3b081-fbcc-4d47-bc26-ef509f9bbadb"
      },
      "name" : "c5a3b081-fbcc-4d47-bc26-ef509f9bbadb",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-c5cd3ab6-1fe8-43f9-9f8b-fa865001f042.html"
      }],
      "reference" : {
        "reference" : "Bundle/c5cd3ab6-1fe8-43f9-9f8b-fa865001f042"
      },
      "name" : "c5cd3ab6-1fe8-43f9-9f8b-fa865001f042",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-c81c571f-8dc3-4703-9bb2-3aee398e4906.html"
      }],
      "reference" : {
        "reference" : "Bundle/c81c571f-8dc3-4703-9bb2-3aee398e4906"
      },
      "name" : "c81c571f-8dc3-4703-9bb2-3aee398e4906",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-c932935c-96bd-424b-a02d-a40833124898.html"
      }],
      "reference" : {
        "reference" : "Bundle/c932935c-96bd-424b-a02d-a40833124898"
      },
      "name" : "c932935c-96bd-424b-a02d-a40833124898",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-cbe04525-e949-4b14-b0e5-d6ac74053543.html"
      }],
      "reference" : {
        "reference" : "Bundle/cbe04525-e949-4b14-b0e5-d6ac74053543"
      },
      "name" : "cbe04525-e949-4b14-b0e5-d6ac74053543",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-d2877e2d-4887-4bab-8f04-52c6fc805160.html"
      }],
      "reference" : {
        "reference" : "Bundle/d2877e2d-4887-4bab-8f04-52c6fc805160"
      },
      "name" : "d2877e2d-4887-4bab-8f04-52c6fc805160",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-d7b2a28c-4fa6-4892-a7c3-4b2ddb0e9f0b.html"
      }],
      "reference" : {
        "reference" : "Bundle/d7b2a28c-4fa6-4892-a7c3-4b2ddb0e9f0b"
      },
      "name" : "d7b2a28c-4fa6-4892-a7c3-4b2ddb0e9f0b",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-db544ae8-d4cb-41ff-82bd-ab28e3064a57.html"
      }],
      "reference" : {
        "reference" : "Bundle/db544ae8-d4cb-41ff-82bd-ab28e3064a57"
      },
      "name" : "db544ae8-d4cb-41ff-82bd-ab28e3064a57",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-de256b2f-7129-4d43-9922-86780f9d80f4.html"
      }],
      "reference" : {
        "reference" : "Bundle/de256b2f-7129-4d43-9922-86780f9d80f4"
      },
      "name" : "de256b2f-7129-4d43-9922-86780f9d80f4",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-e003b0ef-e3ed-481f-a92f-61b7b5c85b0e.html"
      }],
      "reference" : {
        "reference" : "Bundle/e003b0ef-e3ed-481f-a92f-61b7b5c85b0e"
      },
      "name" : "e003b0ef-e3ed-481f-a92f-61b7b5c85b0e",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-e86125ce-879c-4a76-94b4-5b1868d52cd6.html"
      }],
      "reference" : {
        "reference" : "Bundle/e86125ce-879c-4a76-94b4-5b1868d52cd6"
      },
      "name" : "e86125ce-879c-4a76-94b4-5b1868d52cd6",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-e973ba58-6562-4990-b000-f056c2875dbd.html"
      }],
      "reference" : {
        "reference" : "Bundle/e973ba58-6562-4990-b000-f056c2875dbd"
      },
      "name" : "e973ba58-6562-4990-b000-f056c2875dbd",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-e985c502-0b71-4daf-b6a9-16cabb53ad37.html"
      }],
      "reference" : {
        "reference" : "Bundle/e985c502-0b71-4daf-b6a9-16cabb53ad37"
      },
      "name" : "e985c502-0b71-4daf-b6a9-16cabb53ad37",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-ea89d119-ca44-4159-a8d9-8dd13e399718.html"
      }],
      "reference" : {
        "reference" : "Bundle/ea89d119-ca44-4159-a8d9-8dd13e399718"
      },
      "name" : "ea89d119-ca44-4159-a8d9-8dd13e399718",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-ed4bb302-4034-405a-b4c8-39e3b2a4dd1e.html"
      }],
      "reference" : {
        "reference" : "Bundle/ed4bb302-4034-405a-b4c8-39e3b2a4dd1e"
      },
      "name" : "ed4bb302-4034-405a-b4c8-39e3b2a4dd1e",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-f4ceafb2-1486-470a-9309-64f5620345e1.html"
      }],
      "reference" : {
        "reference" : "Bundle/f4ceafb2-1486-470a-9309-64f5620345e1"
      },
      "name" : "f4ceafb2-1486-470a-9309-64f5620345e1",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-f93b6159-a99e-41cc-9e54-bdf0b4d9ed90.html"
      }],
      "reference" : {
        "reference" : "Bundle/f93b6159-a99e-41cc-9e54-bdf0b4d9ed90"
      },
      "name" : "f93b6159-a99e-41cc-9e54-bdf0b4d9ed90",
      "exampleBoolean" : false
    }],
    "page" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
        "valueUrl" : "toc.html"
      }],
      "nameUrl" : "toc.html",
      "title" : "Table of Contents",
      "generation" : "html",
      "page" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "index.html"
        }],
        "nameUrl" : "index.html",
        "title" : "Home",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "downloads.html"
        }],
        "nameUrl" : "downloads.html",
        "title" : "Downloads",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "testexamples.html"
        }],
        "nameUrl" : "testexamples.html",
        "title" : "Testexamples",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "testscripts.html"
        }],
        "nameUrl" : "testscripts.html",
        "title" : "Testscripts",
        "generation" : "markdown"
      }]
    },
    "parameter" : [{
      "code" : "path-resource",
      "value" : "input/capabilities"
    },
    {
      "code" : "path-resource",
      "value" : "input/examples"
    },
    {
      "code" : "path-resource",
      "value" : "input/extensions"
    },
    {
      "code" : "path-resource",
      "value" : "input/models"
    },
    {
      "code" : "path-resource",
      "value" : "input/operations"
    },
    {
      "code" : "path-resource",
      "value" : "input/profiles"
    },
    {
      "code" : "path-resource",
      "value" : "input/resources"
    },
    {
      "code" : "path-resource",
      "value" : "input/vocabulary"
    },
    {
      "code" : "path-resource",
      "value" : "input/maps"
    },
    {
      "code" : "path-resource",
      "value" : "input/testing"
    },
    {
      "code" : "path-resource",
      "value" : "input/history"
    },
    {
      "code" : "path-resource",
      "value" : "fsh-generated/resources"
    },
    {
      "code" : "path-pages",
      "value" : "template/config"
    },
    {
      "code" : "path-pages",
      "value" : "input/images"
    },
    {
      "code" : "path-tx-cache",
      "value" : "input-cache/txcache"
    }]
  }
}

```
