# f93b6159-a99e-41cc-9e54-bdf0b4d9ed90 - HospitalNotification Testscripts v3.0.3

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **f93b6159-a99e-41cc-9e54-bdf0b4d9ed90**

## Bundle: f93b6159-a99e-41cc-9e54-bdf0b4d9ed90



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "f93b6159-a99e-41cc-9e54-bdf0b4d9ed90",
  "meta" : {
    "profile" : ["http://medcomfhir.dk/ig/hospitalnotification/StructureDefinition/medcom-hospitalNotification-message"]
  },
  "type" : "message",
  "timestamp" : "2026-05-01T06:42:55Z",
  "entry" : [{
    "fullUrl" : "https://medcomfhir.dk/ig/hospitalnotification/MessageHeader/aa6445b9-9e57-49af-9c94-1f17e57f4664",
    "resource" : {
      "resourceType" : "MessageHeader",
      "id" : "aa6445b9-9e57-49af-9c94-1f17e57f4664",
      "meta" : {
        "profile" : ["http://medcomfhir.dk/ig/hospitalnotification/StructureDefinition/medcom-hospitalNotification-messageHeader"]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MessageHeader_aa6445b9-9e57-49af-9c94-1f17e57f4664\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MessageHeader aa6445b9-9e57-49af-9c94-1f17e57f4664</b></p><a name=\"aa6445b9-9e57-49af-9c94-1f17e57f4664\"> </a><a name=\"hcaa6445b9-9e57-49af-9c94-1f17e57f4664\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-medcom-hospitalNotification-messageHeader.html\">MedComHospitalNotificationMessageHeader</a></p></div><p><b>MedComReportOfAdmissionExtension</b>: true</p><p><b>MedComReportOfAdmissionRecipientExtension</b>: <a href=\"Organization-d61d3f02-2feb-4464-8cb5-b746269beb30.html\">Organization Hjerteafdelingen på Herlev og Gentofte hospital</a></p><p><b>event</b>: <a href=\"http://medcomfhir.dk/ig/terminology/1.5.0/CodeSystem-medcom-messaging-eventCodes.html#medcom-messaging-eventCodes-hospital-notification-message\">MedComMessagingEventCodes: hospital-notification-message</a> (Hospital Notification Message)</p><h3>Destinations</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Extension</b></td><td><b>Endpoint</b></td><td><b>Receiver</b></td></tr><tr><td style=\"display: none\">*</td><td/><td><a href=\"https://sor2.sum.dsdn.dk/#id=953741000016009\">https://sor2.sum.dsdn.dk/#id=953741000016009</a></td><td><a href=\"Organization-8185eab9-3e2c-4c20-ad36-f7e827e0c8e7.html\">Organization Plejecenter Herlev</a></td></tr></table><p><b>sender</b>: <a href=\"Organization-d61d3f02-2feb-4464-8cb5-b746269beb30.html\">Organization Hjerteafdelingen på Herlev og Gentofte hospital</a></p><h3>Sources</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Endpoint</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"https://sor2.sum.dsdn.dk/#id=265161000016000\">https://sor2.sum.dsdn.dk/#id=265161000016000</a></td></tr></table><p><b>focus</b>: <a href=\"Encounter-4f9ef9df-c696-4223-9133-8793f1be2856.html\">Encounter: status = in-progress; class = inpatient encounter (ActCode#IMP); period = 2026-03-01 12:00:00+0100 --&gt; (ongoing)</a></p></div>"
      },
      "extension" : [{
        "url" : "http://medcomfhir.dk/ig/hospitalnotification/StructureDefinition/medcom-messaging-reportOfAdmissionExtension",
        "valueBoolean" : true
      },
      {
        "url" : "http://medcomfhir.dk/ig/hospitalnotification/StructureDefinition/medcom-messaging-reportOfAdmissionRecipientExtension",
        "valueReference" : {
          "reference" : "Organization/d61d3f02-2feb-4464-8cb5-b746269beb30"
        }
      }],
      "eventCoding" : {
        "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-messaging-eventCodes",
        "code" : "hospital-notification-message"
      },
      "destination" : [{
        "extension" : [{
          "url" : "http://medcomfhir.dk/ig/messaging/StructureDefinition/medcom-messaging-destinationUseExtension",
          "valueCoding" : {
            "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-messaging-destinationUse",
            "code" : "primary"
          }
        }],
        "endpoint" : "https://sor2.sum.dsdn.dk/#id=953741000016009",
        "receiver" : {
          "reference" : "Organization/8185eab9-3e2c-4c20-ad36-f7e827e0c8e7"
        }
      }],
      "sender" : {
        "reference" : "Organization/d61d3f02-2feb-4464-8cb5-b746269beb30"
      },
      "source" : {
        "endpoint" : "https://sor2.sum.dsdn.dk/#id=265161000016000"
      },
      "focus" : [{
        "reference" : "Encounter/4f9ef9df-c696-4223-9133-8793f1be2856"
      }]
    }
  },
  {
    "fullUrl" : "https://medcomfhir.dk/ig/hospitalnotification/Patient/202417ab-4aa9-4032-99a6-ee668f954830",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "202417ab-4aa9-4032-99a6-ee668f954830",
      "meta" : {
        "profile" : ["http://medcomfhir.dk/ig/core/StructureDefinition/medcom-core-patient"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_202417ab-4aa9-4032-99a6-ee668f954830\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient 202417ab-4aa9-4032-99a6-ee668f954830</b></p><a name=\"202417ab-4aa9-4032-99a6-ee668f954830\"> </a><a name=\"hc202417ab-4aa9-4032-99a6-ee668f954830\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://medcomfhir.dk/ig/core/2.3.0/StructureDefinition-medcom-core-patient.html\">MedComCorePatient</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Elmer (official) (no stated gender), DoB Unknown ( urn:oid:1.2.208.176.1.2#DkCoreDanishCivilRegistrationSystem#2509479989)</p><hr/></div>"
      },
      "identifier" : [{
        "system" : "urn:oid:1.2.208.176.1.2",
        "value" : "2509479989"
      }],
      "name" : [{
        "use" : "official",
        "family" : "Elmer"
      }]
    }
  },
  {
    "fullUrl" : "https://medcomfhir.dk/ig/hospitalnotification/Encounter/4f9ef9df-c696-4223-9133-8793f1be2856",
    "resource" : {
      "resourceType" : "Encounter",
      "id" : "4f9ef9df-c696-4223-9133-8793f1be2856",
      "meta" : {
        "profile" : ["http://medcomfhir.dk/ig/hospitalnotification/StructureDefinition/medcom-hospitalNotification-encounter"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Encounter_4f9ef9df-c696-4223-9133-8793f1be2856\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Encounter 4f9ef9df-c696-4223-9133-8793f1be2856</b></p><a name=\"4f9ef9df-c696-4223-9133-8793f1be2856\"> </a><a name=\"hc4f9ef9df-c696-4223-9133-8793f1be2856\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-medcom-hospitalNotification-encounter.html\">MedComHospitalNotificationEncounter</a></p></div><p><b>status</b>: In Progress</p><p><b>class</b>: <a href=\"http://terminology.hl7.org/7.3.0/CodeSystem-v3-ActCode.html#v3-ActCode-IMP\">ActCode: IMP</a> (inpatient encounter)</p><p><b>subject</b>: <a href=\"Patient-202417ab-4aa9-4032-99a6-ee668f954830.html\">Elmer (official) (no stated gender), DoB Unknown ( urn:oid:1.2.208.176.1.2#DkCoreDanishCivilRegistrationSystem#2509479989)</a></p><p><b>episodeOfCare</b>: Identifier: <code>https://sor2.sum.dsdn.dk/#id=265161000016000</code>/d340897d-f650-4589-abe7-95ae467623f7</p><p><b>period</b>: 2026-03-01 12:00:00+0100 --&gt; (ongoing)</p><p><b>serviceProvider</b>: <a href=\"Organization-d61d3f02-2feb-4464-8cb5-b746269beb30.html\">Organization Hjerteafdelingen på Herlev og Gentofte hospital</a></p></div>"
      },
      "status" : "in-progress",
      "class" : {
        "system" : "http://terminology.hl7.org/CodeSystem/v3-ActCode",
        "code" : "IMP"
      },
      "subject" : {
        "reference" : "Patient/202417ab-4aa9-4032-99a6-ee668f954830"
      },
      "episodeOfCare" : [{
        "identifier" : {
          "system" : "https://sor2.sum.dsdn.dk/#id=265161000016000",
          "value" : "d340897d-f650-4589-abe7-95ae467623f7"
        }
      }],
      "period" : {
        "start" : "2026-03-01T12:00:00+01:00"
      },
      "serviceProvider" : {
        "reference" : "Organization/d61d3f02-2feb-4464-8cb5-b746269beb30"
      }
    }
  },
  {
    "fullUrl" : "https://medcomfhir.dk/ig/hospitalnotification/Organization/8185eab9-3e2c-4c20-ad36-f7e827e0c8e7",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "8185eab9-3e2c-4c20-ad36-f7e827e0c8e7",
      "meta" : {
        "profile" : ["http://medcomfhir.dk/ig/messaging/StructureDefinition/medcom-messaging-organization"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_8185eab9-3e2c-4c20-ad36-f7e827e0c8e7\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization 8185eab9-3e2c-4c20-ad36-f7e827e0c8e7</b></p><a name=\"8185eab9-3e2c-4c20-ad36-f7e827e0c8e7\"> </a><a name=\"hc8185eab9-3e2c-4c20-ad36-f7e827e0c8e7\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://medcomfhir.dk/ig/messaging/2.1.0/StructureDefinition-medcom-messaging-organization.html\">MedComMessagingOrganization</a></p></div><p><b>identifier</b>: <code>https://www.gs1.org/gln</code>/5790001348120, <code>urn:oid:1.2.208.176.1.1</code>/953741000016009</p><p><b>name</b>: Plejecenter Herlev</p></div>"
      },
      "identifier" : [{
        "system" : "https://www.gs1.org/gln",
        "value" : "5790001348120"
      },
      {
        "system" : "urn:oid:1.2.208.176.1.1",
        "value" : "953741000016009"
      }],
      "name" : "Plejecenter Herlev"
    }
  },
  {
    "fullUrl" : "https://medcomfhir.dk/ig/hospitalnotification/Organization/d61d3f02-2feb-4464-8cb5-b746269beb30",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "d61d3f02-2feb-4464-8cb5-b746269beb30",
      "meta" : {
        "profile" : ["http://medcomfhir.dk/ig/messaging/StructureDefinition/medcom-messaging-organization"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_d61d3f02-2feb-4464-8cb5-b746269beb30\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization d61d3f02-2feb-4464-8cb5-b746269beb30</b></p><a name=\"d61d3f02-2feb-4464-8cb5-b746269beb30\"> </a><a name=\"hcd61d3f02-2feb-4464-8cb5-b746269beb30\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://medcomfhir.dk/ig/messaging/2.1.0/StructureDefinition-medcom-messaging-organization.html\">MedComMessagingOrganization</a></p></div><p><b>identifier</b>: <code>https://www.gs1.org/gln</code>/5790000209354, <code>urn:oid:1.2.208.176.1.1</code>/265161000016000</p><p><b>name</b>: Hjerteafdelingen på Herlev og Gentofte hospital</p></div>"
      },
      "identifier" : [{
        "system" : "https://www.gs1.org/gln",
        "value" : "5790000209354"
      },
      {
        "system" : "urn:oid:1.2.208.176.1.1",
        "value" : "265161000016000"
      }],
      "name" : "Hjerteafdelingen på Herlev og Gentofte hospital"
    }
  },
  {
    "fullUrl" : "https://medcomfhir.dk/ig/hospitalnotification/Provenance/554d2fa8-3bdd-4fda-879a-50058aa87a8c",
    "resource" : {
      "resourceType" : "Provenance",
      "id" : "554d2fa8-3bdd-4fda-879a-50058aa87a8c",
      "meta" : {
        "profile" : ["http://medcomfhir.dk/ig/messaging/StructureDefinition/medcom-messaging-provenance"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Provenance_554d2fa8-3bdd-4fda-879a-50058aa87a8c\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Provenance 554d2fa8-3bdd-4fda-879a-50058aa87a8c</b></p><a name=\"554d2fa8-3bdd-4fda-879a-50058aa87a8c\"> </a><a name=\"hc554d2fa8-3bdd-4fda-879a-50058aa87a8c\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://medcomfhir.dk/ig/messaging/2.1.0/StructureDefinition-medcom-messaging-provenance.html\">MedComMessagingProvenance</a></p></div><p>Provenance for <a href=\"MessageHeader-aa6445b9-9e57-49af-9c94-1f17e57f4664.html\">MessageHeader: extension = true,-&gt;Organization Hjerteafdelingen på Herlev og Gentofte hospital; event[x] = Hospital Notification Message (MedComMessagingEventCodes#hospital-notification-message)</a></p><p>Summary</p><table class=\"grid\"><tr><td>Occurrence</td><td>2026-03-01 12:00:02+0100</td></tr><tr><td>Recorded</td><td>2026-03-01 12:00:02+0100</td></tr><tr><td>Activity</td><td><span title=\"Codes:{http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-messaging-activityCodes admit-inpatient}\">Start hospital stay - admitted</span></td></tr></table><p><b>Agents</b></p><table class=\"grid\"><tr><td><b>who</b></td></tr><tr><td><a href=\"Organization-d61d3f02-2feb-4464-8cb5-b746269beb30.html\">Organization Hjerteafdelingen på Herlev og Gentofte hospital</a></td></tr></table></div>"
      },
      "target" : [{
        "reference" : "MessageHeader/aa6445b9-9e57-49af-9c94-1f17e57f4664"
      }],
      "occurredDateTime" : "2026-03-01T12:00:02+01:00",
      "recorded" : "2026-03-01T12:00:02+01:00",
      "activity" : {
        "coding" : [{
          "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-messaging-activityCodes",
          "code" : "admit-inpatient"
        }]
      },
      "agent" : [{
        "who" : {
          "reference" : "Organization/d61d3f02-2feb-4464-8cb5-b746269beb30"
        }
      }]
    }
  }]
}

```
