# bec4ba50-a0ed-4d98-a618-78ec3c5ed4c3 - HospitalNotification Testscripts v3.0.3

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **bec4ba50-a0ed-4d98-a618-78ec3c5ed4c3**

## Bundle: bec4ba50-a0ed-4d98-a618-78ec3c5ed4c3



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "bec4ba50-a0ed-4d98-a618-78ec3c5ed4c3",
  "meta" : {
    "profile" : ["http://medcomfhir.dk/ig/hospitalnotification/StructureDefinition/medcom-hospitalNotification-message"]
  },
  "type" : "message",
  "timestamp" : "2026-02-28T10:00:06+01:00",
  "entry" : [{
    "fullUrl" : "https://medcomfhir.dk/ig/hospitalnotification/MessageHeader/f8acf62f-66e9-4f2b-a176-e40f668331c8",
    "resource" : {
      "resourceType" : "MessageHeader",
      "id" : "f8acf62f-66e9-4f2b-a176-e40f668331c8",
      "meta" : {
        "profile" : ["http://medcomfhir.dk/ig/hospitalnotification/StructureDefinition/medcom-hospitalNotification-messageHeader"]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MessageHeader_f8acf62f-66e9-4f2b-a176-e40f668331c8\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MessageHeader f8acf62f-66e9-4f2b-a176-e40f668331c8</b></p><a name=\"f8acf62f-66e9-4f2b-a176-e40f668331c8\"> </a><a name=\"hcf8acf62f-66e9-4f2b-a176-e40f668331c8\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-medcom-hospitalNotification-messageHeader.html\">MedComHospitalNotificationMessageHeader</a></p></div><p><b>MedComReportOfAdmissionExtension</b>: true</p><p><b>MedComReportOfAdmissionRecipientExtension</b>: <a href=\"Organization-9da96249-762f-4b2f-b5a2-6be9595f6175.html\">Organization Hjerteafdelingen på Herlev og Gentofte hospital</a></p><p><b>event</b>: <a href=\"http://medcomfhir.dk/ig/terminology/1.5.0/CodeSystem-medcom-messaging-eventCodes.html#medcom-messaging-eventCodes-hospital-notification-message\">MedComMessagingEventCodes: hospital-notification-message</a> (Hospital Notification Message)</p><h3>Destinations</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Extension</b></td><td><b>Endpoint</b></td><td><b>Receiver</b></td></tr><tr><td style=\"display: none\">*</td><td/><td><a href=\"https://sor2.sum.dsdn.dk/#id=953741000016009\">https://sor2.sum.dsdn.dk/#id=953741000016009</a></td><td><a href=\"Organization-04910f14-b85b-401f-b303-a939be8038fe.html\">Organization Plejecenter Herlev</a></td></tr></table><p><b>sender</b>: <a href=\"Organization-9da96249-762f-4b2f-b5a2-6be9595f6175.html\">Organization Hjerteafdelingen på Herlev og Gentofte hospital</a></p><h3>Sources</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Endpoint</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"https://sor2.sum.dsdn.dk/#id=265161000016000\">https://sor2.sum.dsdn.dk/#id=265161000016000</a></td></tr></table><p><b>focus</b>: <a href=\"Encounter-7a66df38-3cd6-4418-a08d-4a344f78be06.html\">Encounter: status = in-progress; class = emergency (ActCode#EMER); period = 2026-02-28 10:00:04+0100 --&gt; (ongoing)</a></p></div>"
      },
      "extension" : [{
        "url" : "http://medcomfhir.dk/ig/hospitalnotification/StructureDefinition/medcom-messaging-reportOfAdmissionExtension",
        "valueBoolean" : true
      },
      {
        "url" : "http://medcomfhir.dk/ig/hospitalnotification/StructureDefinition/medcom-messaging-reportOfAdmissionRecipientExtension",
        "valueReference" : {
          "reference" : "Organization/9da96249-762f-4b2f-b5a2-6be9595f6175"
        }
      }],
      "eventCoding" : {
        "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-messaging-eventCodes",
        "code" : "hospital-notification-message"
      },
      "destination" : [{
        "extension" : [{
          "url" : "http://medcomfhir.dk/ig/messaging/StructureDefinition/medcom-messaging-destinationUseExtension",
          "valueCoding" : {
            "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-messaging-destinationUse",
            "code" : "primary"
          }
        }],
        "endpoint" : "https://sor2.sum.dsdn.dk/#id=953741000016009",
        "receiver" : {
          "reference" : "Organization/04910f14-b85b-401f-b303-a939be8038fe"
        }
      }],
      "sender" : {
        "reference" : "Organization/9da96249-762f-4b2f-b5a2-6be9595f6175"
      },
      "source" : {
        "endpoint" : "https://sor2.sum.dsdn.dk/#id=265161000016000"
      },
      "focus" : [{
        "reference" : "Encounter/7a66df38-3cd6-4418-a08d-4a344f78be06"
      }]
    }
  },
  {
    "fullUrl" : "https://medcomfhir.dk/ig/hospitalnotification/Patient/4db66706-58e2-45f4-9fae-81a01e008675",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "4db66706-58e2-45f4-9fae-81a01e008675",
      "meta" : {
        "profile" : ["http://medcomfhir.dk/ig/core/StructureDefinition/medcom-core-patient"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_4db66706-58e2-45f4-9fae-81a01e008675\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient 4db66706-58e2-45f4-9fae-81a01e008675</b></p><a name=\"4db66706-58e2-45f4-9fae-81a01e008675\"> </a><a name=\"hc4db66706-58e2-45f4-9fae-81a01e008675\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://medcomfhir.dk/ig/core/2.3.0/StructureDefinition-medcom-core-patient.html\">MedComCorePatient</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Elmer (official) (no stated gender), DoB Unknown ( urn:oid:1.2.208.176.1.2#DkCoreDanishCivilRegistrationSystem#2509479989)</p><hr/></div>"
      },
      "identifier" : [{
        "system" : "urn:oid:1.2.208.176.1.2",
        "value" : "2509479989"
      }],
      "name" : [{
        "use" : "official",
        "family" : "Elmer"
      }]
    }
  },
  {
    "fullUrl" : "https://medcomfhir.dk/ig/hospitalnotification/Encounter/7a66df38-3cd6-4418-a08d-4a344f78be06",
    "resource" : {
      "resourceType" : "Encounter",
      "id" : "7a66df38-3cd6-4418-a08d-4a344f78be06",
      "meta" : {
        "profile" : ["http://medcomfhir.dk/ig/hospitalnotification/StructureDefinition/medcom-hospitalNotification-encounter"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Encounter_7a66df38-3cd6-4418-a08d-4a344f78be06\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Encounter 7a66df38-3cd6-4418-a08d-4a344f78be06</b></p><a name=\"7a66df38-3cd6-4418-a08d-4a344f78be06\"> </a><a name=\"hc7a66df38-3cd6-4418-a08d-4a344f78be06\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-medcom-hospitalNotification-encounter.html\">MedComHospitalNotificationEncounter</a></p></div><p><b>status</b>: In Progress</p><p><b>class</b>: <a href=\"http://terminology.hl7.org/7.3.0/CodeSystem-v3-ActCode.html#v3-ActCode-EMER\">ActCode: EMER</a> (emergency)</p><p><b>subject</b>: <a href=\"Patient-4db66706-58e2-45f4-9fae-81a01e008675.html\">Elmer (official) (no stated gender), DoB Unknown ( urn:oid:1.2.208.176.1.2#DkCoreDanishCivilRegistrationSystem#2509479989)</a></p><p><b>episodeOfCare</b>: Identifier: <code>https://sor2.sum.dsdn.dk/#id=265161000016000</code>/c1280ebe-676b-480f-b27c-545972b4888e</p><p><b>period</b>: 2026-02-28 10:00:04+0100 --&gt; (ongoing)</p><p><b>serviceProvider</b>: <a href=\"Organization-9da96249-762f-4b2f-b5a2-6be9595f6175.html\">Organization Hjerteafdelingen på Herlev og Gentofte hospital</a></p></div>"
      },
      "status" : "in-progress",
      "class" : {
        "system" : "http://terminology.hl7.org/CodeSystem/v3-ActCode",
        "code" : "EMER"
      },
      "subject" : {
        "reference" : "Patient/4db66706-58e2-45f4-9fae-81a01e008675"
      },
      "episodeOfCare" : [{
        "identifier" : {
          "system" : "https://sor2.sum.dsdn.dk/#id=265161000016000",
          "value" : "c1280ebe-676b-480f-b27c-545972b4888e"
        }
      }],
      "period" : {
        "start" : "2026-02-28T10:00:04+01:00"
      },
      "serviceProvider" : {
        "reference" : "Organization/9da96249-762f-4b2f-b5a2-6be9595f6175"
      }
    }
  },
  {
    "fullUrl" : "https://medcomfhir.dk/ig/hospitalnotification/Organization/04910f14-b85b-401f-b303-a939be8038fe",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "04910f14-b85b-401f-b303-a939be8038fe",
      "meta" : {
        "profile" : ["http://medcomfhir.dk/ig/messaging/StructureDefinition/medcom-messaging-organization"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_04910f14-b85b-401f-b303-a939be8038fe\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization 04910f14-b85b-401f-b303-a939be8038fe</b></p><a name=\"04910f14-b85b-401f-b303-a939be8038fe\"> </a><a name=\"hc04910f14-b85b-401f-b303-a939be8038fe\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://medcomfhir.dk/ig/messaging/2.1.0/StructureDefinition-medcom-messaging-organization.html\">MedComMessagingOrganization</a></p></div><p><b>identifier</b>: <code>https://www.gs1.org/gln</code>/5790001348120, <code>urn:oid:1.2.208.176.1.1</code>/953741000016009</p><p><b>name</b>: Plejecenter Herlev</p></div>"
      },
      "identifier" : [{
        "system" : "https://www.gs1.org/gln",
        "value" : "5790001348120"
      },
      {
        "system" : "urn:oid:1.2.208.176.1.1",
        "value" : "953741000016009"
      }],
      "name" : "Plejecenter Herlev"
    }
  },
  {
    "fullUrl" : "https://medcomfhir.dk/ig/hospitalnotification/Organization/9da96249-762f-4b2f-b5a2-6be9595f6175",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "9da96249-762f-4b2f-b5a2-6be9595f6175",
      "meta" : {
        "profile" : ["http://medcomfhir.dk/ig/messaging/StructureDefinition/medcom-messaging-organization"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_9da96249-762f-4b2f-b5a2-6be9595f6175\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization 9da96249-762f-4b2f-b5a2-6be9595f6175</b></p><a name=\"9da96249-762f-4b2f-b5a2-6be9595f6175\"> </a><a name=\"hc9da96249-762f-4b2f-b5a2-6be9595f6175\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://medcomfhir.dk/ig/messaging/2.1.0/StructureDefinition-medcom-messaging-organization.html\">MedComMessagingOrganization</a></p></div><p><b>identifier</b>: <code>https://www.gs1.org/gln</code>/5790000209354, <code>urn:oid:1.2.208.176.1.1</code>/265161000016000</p><p><b>name</b>: Hjerteafdelingen på Herlev og Gentofte hospital</p></div>"
      },
      "identifier" : [{
        "system" : "https://www.gs1.org/gln",
        "value" : "5790000209354"
      },
      {
        "system" : "urn:oid:1.2.208.176.1.1",
        "value" : "265161000016000"
      }],
      "name" : "Hjerteafdelingen på Herlev og Gentofte hospital"
    }
  },
  {
    "fullUrl" : "https://medcomfhir.dk/ig/hospitalnotification/Provenance/a484da1b-7844-49b2-b395-762bf82a5e40",
    "resource" : {
      "resourceType" : "Provenance",
      "id" : "a484da1b-7844-49b2-b395-762bf82a5e40",
      "meta" : {
        "profile" : ["http://medcomfhir.dk/ig/messaging/StructureDefinition/medcom-messaging-provenance"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Provenance_a484da1b-7844-49b2-b395-762bf82a5e40\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Provenance a484da1b-7844-49b2-b395-762bf82a5e40</b></p><a name=\"a484da1b-7844-49b2-b395-762bf82a5e40\"> </a><a name=\"hca484da1b-7844-49b2-b395-762bf82a5e40\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://medcomfhir.dk/ig/messaging/2.1.0/StructureDefinition-medcom-messaging-provenance.html\">MedComMessagingProvenance</a></p></div><p>Provenance for <a href=\"MessageHeader-f8acf62f-66e9-4f2b-a176-e40f668331c8.html\">MessageHeader: extension = true,-&gt;Organization Hjerteafdelingen på Herlev og Gentofte hospital; event[x] = Hospital Notification Message (MedComMessagingEventCodes#hospital-notification-message)</a></p><p>Summary</p><table class=\"grid\"><tr><td>Occurrence</td><td>2026-02-28 10:00:06+0100</td></tr><tr><td>Recorded</td><td>2026-02-28 10:00:06+0100</td></tr><tr><td>Activity</td><td><span title=\"Codes:{http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-messaging-activityCodes admit-emergency}\">Start hospital stay - acute ambulant</span></td></tr></table><p><b>Agents</b></p><table class=\"grid\"><tr><td><b>who</b></td></tr><tr><td><a href=\"Organization-9da96249-762f-4b2f-b5a2-6be9595f6175.html\">Organization Hjerteafdelingen på Herlev og Gentofte hospital</a></td></tr></table></div>"
      },
      "target" : [{
        "reference" : "MessageHeader/f8acf62f-66e9-4f2b-a176-e40f668331c8"
      }],
      "occurredDateTime" : "2026-02-28T10:00:06+01:00",
      "recorded" : "2026-02-28T10:00:06+01:00",
      "activity" : {
        "coding" : [{
          "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-messaging-activityCodes",
          "code" : "admit-emergency"
        }]
      },
      "agent" : [{
        "who" : {
          "reference" : "Organization/9da96249-762f-4b2f-b5a2-6be9595f6175"
        }
      }]
    }
  }]
}

```
