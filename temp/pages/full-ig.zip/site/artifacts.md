# Artifacts Summary - HospitalNotification Testscripts v3.0.3

* [**Table of Contents**](toc.md)
* **Artifacts Summary**

## Artifacts Summary

This page provides a list of the FHIR artifacts defined as part of this implementation guide.

### Other 

These are resources that are used within this implementation guide that do not fit into one of the other categories.

| |
| :--- |
| [172992fd-7910-486b-9039-ae58de0786c8](Bundle-172992fd-7910-486b-9039-ae58de0786c8.md) |
| [1a505c7a-f790-4cb7-9d68-ee8993e84736](Bundle-1a505c7a-f790-4cb7-9d68-ee8993e84736.md) |
| [1acdc074-1793-4651-831d-d45383de88d7](Bundle-1acdc074-1793-4651-831d-d45383de88d7.md) |
| [2f7168e9-9c1f-4103-a30a-e5c4acf05c45](Bundle-2f7168e9-9c1f-4103-a30a-e5c4acf05c45.md) |
| [36c3dd0e-7212-4e97-b857-507f91a36ee5](Bundle-36c3dd0e-7212-4e97-b857-507f91a36ee5.md) |
| [373df375-0eee-4d48-9fee-2381991d55ba](Bundle-373df375-0eee-4d48-9fee-2381991d55ba.md) |
| [37dfb04f-86c6-4d86-96a5-f2334c1af711](Bundle-37dfb04f-86c6-4d86-96a5-f2334c1af711.md) |
| [650a355e-438e-41c7-a7f1-0e3e0df18e16](Bundle-650a355e-438e-41c7-a7f1-0e3e0df18e16.md) |
| [69b98015-a0af-4e09-99bf-85e08a62479c](Bundle-69b98015-a0af-4e09-99bf-85e08a62479c.md) |
| [7502c124-03b0-4347-8edf-424b0c978627](Bundle-7502c124-03b0-4347-8edf-424b0c978627.md) |
| [7b380ba1-6d36-4c59-9878-1d9875011a6b](Bundle-7b380ba1-6d36-4c59-9878-1d9875011a6b.md) |
| [857fc416-31c1-4724-9a2e-da3888aa5562](Bundle-857fc416-31c1-4724-9a2e-da3888aa5562.md) |
| [9008049a-98cb-4a0e-82a0-89f1a8aca70d](Bundle-9008049a-98cb-4a0e-82a0-89f1a8aca70d.md) |
| [9011f888-3bcc-46d6-848b-297aca060e7f](Bundle-9011f888-3bcc-46d6-848b-297aca060e7f.md) |
| [909f89db-2f6c-458d-a3e6-bda0c1603194](Bundle-909f89db-2f6c-458d-a3e6-bda0c1603194.md) |
| [912b06fc-5530-444b-abe1-ea06eee61cce](Bundle-912b06fc-5530-444b-abe1-ea06eee61cce.md) |
| [920d2d1e-8c21-462c-9917-10b18eefba3f](Bundle-920d2d1e-8c21-462c-9917-10b18eefba3f.md) |
| [9a1b6304-9a5e-41d4-9460-442cc11d4d6c](Bundle-9a1b6304-9a5e-41d4-9460-442cc11d4d6c.md) |
| [9e7da343-d585-4cca-b3bb-e06ea27ae62a](Bundle-9e7da343-d585-4cca-b3bb-e06ea27ae62a.md) |
| [a0536ce3-9687-4c3f-a753-47d37dc8cb04](Bundle-a0536ce3-9687-4c3f-a753-47d37dc8cb04.md) |
| [a6cebbce-2b7a-478f-aefd-57305f3b05c1](Bundle-a6cebbce-2b7a-478f-aefd-57305f3b05c1.md) |
| [b40c8da9-81b5-473b-898e-c8536cb36d34](Bundle-b40c8da9-81b5-473b-898e-c8536cb36d34.md) |
| [b4625f1e-ba87-4f11-95b2-9f1923a006ec](Bundle-b4625f1e-ba87-4f11-95b2-9f1923a006ec.md) |
| [b9c4da96-8f0e-48b8-bf1d-87899f663d01](Bundle-b9c4da96-8f0e-48b8-bf1d-87899f663d01.md) |
| [bec4ba50-a0ed-4d98-a618-78ec3c5ed4c3](Bundle-bec4ba50-a0ed-4d98-a618-78ec3c5ed4c3.md) |
| [c5a3b081-fbcc-4d47-bc26-ef509f9bbadb](Bundle-c5a3b081-fbcc-4d47-bc26-ef509f9bbadb.md) |
| [c5cd3ab6-1fe8-43f9-9f8b-fa865001f042](Bundle-c5cd3ab6-1fe8-43f9-9f8b-fa865001f042.md) |
| [c81c571f-8dc3-4703-9bb2-3aee398e4906](Bundle-c81c571f-8dc3-4703-9bb2-3aee398e4906.md) |
| [c932935c-96bd-424b-a02d-a40833124898](Bundle-c932935c-96bd-424b-a02d-a40833124898.md) |
| [cbe04525-e949-4b14-b0e5-d6ac74053543](Bundle-cbe04525-e949-4b14-b0e5-d6ac74053543.md) |
| [d2877e2d-4887-4bab-8f04-52c6fc805160](Bundle-d2877e2d-4887-4bab-8f04-52c6fc805160.md) |
| [d7b2a28c-4fa6-4892-a7c3-4b2ddb0e9f0b](Bundle-d7b2a28c-4fa6-4892-a7c3-4b2ddb0e9f0b.md) |
| [db544ae8-d4cb-41ff-82bd-ab28e3064a57](Bundle-db544ae8-d4cb-41ff-82bd-ab28e3064a57.md) |
| [de256b2f-7129-4d43-9922-86780f9d80f4](Bundle-de256b2f-7129-4d43-9922-86780f9d80f4.md) |
| [e003b0ef-e3ed-481f-a92f-61b7b5c85b0e](Bundle-e003b0ef-e3ed-481f-a92f-61b7b5c85b0e.md) |
| [e86125ce-879c-4a76-94b4-5b1868d52cd6](Bundle-e86125ce-879c-4a76-94b4-5b1868d52cd6.md) |
| [e973ba58-6562-4990-b000-f056c2875dbd](Bundle-e973ba58-6562-4990-b000-f056c2875dbd.md) |
| [e985c502-0b71-4daf-b6a9-16cabb53ad37](Bundle-e985c502-0b71-4daf-b6a9-16cabb53ad37.md) |
| [ea89d119-ca44-4159-a8d9-8dd13e399718](Bundle-ea89d119-ca44-4159-a8d9-8dd13e399718.md) |
| [ed4bb302-4034-405a-b4c8-39e3b2a4dd1e](Bundle-ed4bb302-4034-405a-b4c8-39e3b2a4dd1e.md) |
| [f4ceafb2-1486-470a-9309-64f5620345e1](Bundle-f4ceafb2-1486-470a-9309-64f5620345e1.md) |
| [f93b6159-a99e-41cc-9e54-bdf0b4d9ed90](Bundle-f93b6159-a99e-41cc-9e54-bdf0b4d9ed90.md) |

