# Testexamples - HospitalNotification Testscripts v3.0.3

* [**Table of Contents**](toc.md)
* **Testexamples**

## Testexamples

The examples presented below are intended to be used in the test protocol for receiving HospitalNotification. Testprotocols can be found on the [GitHub pages for HospitalNotificaton](https://medcomdk.github.io/dk-medcom-hospitalnotification/#2-test-and-certification). All test examples are created by MedCom.

#### Test patient/citizens

All examples include, except TEK_LOV are based on the test patient:

* Name: Elmer
* CPR-nr.: 250947-9989 For the example TEK_LOV, the follwoing patient is used:
* Name: Kaje Test Hansen
* CPR-nr.: 210300-9996

#### Test examples for receiving HospitalNotification

[Download test examples for receiving a HospitalNotification (.zip)](./HospitalNotification/HospitalNotification_Ex_receive.zip)

| | |
| :--- | :--- |
| [STIN_A](./Bundle-a5e5b880-c087-4055-b9ec-99108695f81d.md) | Notification with information that a citizen has been admitted to hospital (including request for XDIS16) |
| [STIN_B1](./Bundle-3c4c04ea-a622-4c6e-8e62-307a62d4c851.md)[STIN_B2](./Bundle-64e7f154-668d-4d2a-bf76-2cec049b3252.md) | Notification with information that a citizen has been admitted to hospital X, region X (including request for XDIS16)Notification with information that the same citizen has now been admitted to hospital Y, region Y (does not include a request for XDIS16) |
| [STIN_C1](./Bundle-f628d121-52f5-401b-a195-3492b3fec614.md)[STIN_C2](./Bundle-8111a01d-eed2-4244-b079-00afe30d99bd.md) | Notification with information that a citizen has been admitted to hospital X, region X (including request for XDIS16)Notification with information that the same citizen has now been admitted to hospital Y, region X (does not include a request for XDIS16) |
| [STAA_D](./Bundle-2cadabe8-9349-4b2e-9b5e-4441c9aeef4b.md) | Notification with information that a citizen is admitted as an acute outpatient at the hospital (Including request for XDIS16) |
| [STAA_E](./Bundle-d434d732-951c-4dd3-aeb8-2e18f1c81942.md)[STIN_E](./Bundle-ff90d6fc-fa84-4c0f-969d-84510b0ef7e3.md) | Notification with information that a citizen is admitted to hospital as an acute ambulant patient (including request for XDIS16)Notification with information that the same citizen has now been admitted to hospital (does not include a request for XDIS16) |
| [STIN_F](./Bundle-ce5cf7e2-3a37-4b95-9d2c-268c8ec3c576.md)[STOR_F](./Bundle-91a204af-471b-4ce2-b19f-c458e3716070.md) | Notification with information that a citizen has been admitted to hospital (including request for XDIS16)Notification with information that the same citizen is taking leave from the hospital stay (does not include a request for XDIS16) |
| [STIN_G](./Bundle-67df3ce8-0cdb-4e91-937c-d8a3025867e7.md)[STOR_G](./Bundle-ec49747c-6005-4732-86b5-c7d2ec9f173d.md)[SLOR_G](./Bundle-5248a961-331b-4f22-8593-75cdd8d7e36c.md) | Notification with information that a citizen has been admitted to hospital (including request for XDIS16)Notification with information that the same citizen is taking leave from hospital (does not include a request for XDIS16)Notification with information that the same citizen has now ended leave from hospital stay (does not include a request for XDIS16) |
| [STIN_H](./Bundle-2361f9af-3411-4f87-93ef-61f501ce01b5.md)[SLHJ_H](./Bundle-5be3a118-64e4-4541-a2fa-a90e3df387d6.md) | Notification with information that a citizen has been admitted to hospital (including request for XDIS16)Notification with information that the same citizen has been discharged and sent home/to primary sector (does not include a request for XDIS16) |
| [STIN_I](./Bundle-079858e5-8687-4f5c-b183-d9688206fd29.md)[STOR_I](./Bundle-cd9b8635-aef9-4518-b52d-35fbd384a7be.md)[SLHJ_I](./Bundle-70dfd9bb-362a-4424-a5b8-98fe11e95f42.md) | Notification with information that a citizen has been admitted to hospital (including request for XDIS16)Notification with information that the same citizen is taking leave from hospital (does not include a request for XDIS16)Notification with information that the same citizen has been discharged and sent home/to primary sector (does not include a request for XDIS16) |
| [MORS_J](./Bundle-04fc7ad0-4c60-450c-9320-2c821e0a0ce0.md) | Notification with information that a citizen is dead |
| [STIN_K](./Bundle-ae2dc2a8-5094-4d20-9ce5-78878066976a.md)[MORS_K](./Bundle-fe1c34a3-460a-431d-a0e3-a2b59fa93a9f.md) | Notification with information that a citizen has been admitted to hospital (including request for XDIS16)Notification with information that the same citizen has died |
| [STIN_L](./Bundle-9b86a65a-1428-46f5-9487-7e5cdfe687fe.md)[STOR_L](./Bundle-abdd86e8-e084-4fad-95ce-fb82c36c5768.md)[MORS_L](./Bundle-cac520bc-f88b-4e7a-b8fd-bb8750e38c7a.md) | Notification with information that a citizen has been admitted to hospital (including request for XDIS16)Notification with information that the same citizen is taking leave from hospital (does not include a request for XDIS16)Notification with information that the same citizen has died (during leave) |
| [STIN_M](./Bundle-82b851ce-4837-49bb-9623-7310d3c83210.md) | Notification with information that a citizen has been admitted to hospital (including request for XDIS16) |
| [STIN_N](./Bundle-5832154e-58d0-4590-9ba0-21661dbe2658.md)[AN_STIN_N](./Bundle-4af4ef94-c452-4e52-8176-b8bd1d059433.md) | Notification with information that a citizen has been admitted to hospital (including request for XDIS16)Notification with information that the notification just sent is cancelled (does not include a request for XDIS16) |
| [STIN_O](./Bundle-3111b274-76e4-403c-8701-ec94edcd2bf2.md)[RE_STIN_O](./Bundle-2094d603-a09c-462c-a1c9-23859ba035f3.md) | Notification with information that a citizen has been admitted to hospital (including request for XDIS16)Notification with corrections to the notification just sent (date/time corrected) (does not include a request for XDIS16) |
| [STIN_P](./Bundle-cc7b9615-3d48-404d-a82a-f4d158839843.md)[RE_STIN_P](./Bundle-4d747862-61ab-48c1-a00e-8f527c985169.md) | Notification with information that a citizen has been admitted to hospital (including request for XDIS16)Notification with corrections to the notification just sent (department corrected) (does not include a request for XDIS16) |
| [AN_STIN_P](./Bundle-3b11cb1c-63df-4206-a7aa-f299c4a206ba.md) | Notification that cancels a notification [STIN_P] that has been corrected [RE_STIN_P] |
| [TEK_STIN_A](./Bundle-271a9b00-0b1c-46ac-b00e-c3193d187c62.md) | Notification with information that a citizen has been admitted to hospital (including request for Acknowledgement) |
| [TEK_ID_LOCAL](./Bundle-28e963f1-f629-44a7-a246-7412ed0e457c.md) | Notification with a locally defined UUID |
| [TEK_ID_LPR3](./Bundle-9fc89121-a0aa-43e0-a753-88bbe142ba91.md) | Notification with LPR3 identifier |
| [TEK_ID_2](./Bundle-9479ce7a-6837-42a5-a4d2-08f09254cbc9.md) | Notification with two identifiers (locally defined UUID + LPR3 identifier) |
| [TEK_STAA_A](./Bundle-34fbe325-7edb-4956-a1db-15f2e053ac4d.md) | Notification with information that the same citizen is admitted as an acute outpatient at the hospital |
| [TEK_SLHJ_A](./Bundle-277a564b-1595-41d7-9d49-95eae2336b59.md) | Notification with information that the same citizen has now been discharged and sent home/to primary sector. |
| [TEK_STIN_B](./Bundle-8d184671-a40a-4236-9579-0445ecf98ea0.md) | Notification with information that a citizen has been admitted to hospital (the time of the incident is between the acute ambulant hospital stay and the discharge).The example is used to test that the citizen’s status continues to appear as ‘completed’/’discharged’ in a hospital stay where the citizen has been acute ambulant, then admitted and finally discharged, but where the Hospital Notification [STIN] was sent/received later than the Hospital Notification [SLHJ]. |
| [TEK_DUB](./Bundle-1a32e7d1-7008-4bd4-907e-1fb6a016f5b8.md) | Notification with information that a citizen has been admitted to hospital (Used to test correct handling of duplicates) |
| [TEK_LOV](./Bundle-71ea109a-a5fb-4301-8609-34d7849190df.md) | Notification with information that a citizen has been admitted to hospital (Used to test the correct handling of citizens who does not have a relevant case in the SUT) |
| [TEK_FCC](./Bundle-17a0c807-372b-452c-972e-c59036153b57.md) | Notification containing errors |

