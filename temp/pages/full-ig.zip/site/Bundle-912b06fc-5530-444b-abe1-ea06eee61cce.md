# 912b06fc-5530-444b-abe1-ea06eee61cce - HospitalNotification Testscripts v3.0.3

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **912b06fc-5530-444b-abe1-ea06eee61cce**

## Bundle: 912b06fc-5530-444b-abe1-ea06eee61cce



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "912b06fc-5530-444b-abe1-ea06eee61cce",
  "meta" : {
    "profile" : ["http://medcomfhir.dk/ig/hospitalnotification/StructureDefinition/medcom-hospitalNotification-message"]
  },
  "type" : "message",
  "timestamp" : "2026-05-01T07:20:56Z",
  "entry" : [{
    "fullUrl" : "https://medcomfhir.dk/ig/hospitalnotification/MessageHeader/fe400034-8a4b-4998-94f4-aef6840c647d",
    "resource" : {
      "resourceType" : "MessageHeader",
      "id" : "fe400034-8a4b-4998-94f4-aef6840c647d",
      "meta" : {
        "profile" : ["http://medcomfhir.dk/ig/hospitalnotification/StructureDefinition/medcom-hospitalNotification-messageHeader"]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MessageHeader_fe400034-8a4b-4998-94f4-aef6840c647d\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MessageHeader fe400034-8a4b-4998-94f4-aef6840c647d</b></p><a name=\"fe400034-8a4b-4998-94f4-aef6840c647d\"> </a><a name=\"hcfe400034-8a4b-4998-94f4-aef6840c647d\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-medcom-hospitalNotification-messageHeader.html\">MedComHospitalNotificationMessageHeader</a></p></div><p><b>MedComReportOfAdmissionExtension</b>: true</p><p><b>MedComReportOfAdmissionRecipientExtension</b>: <a href=\"Organization-bebbaee3-7891-414d-a420-a057a72a4969.html\">Organization Hjerteafdelingen på Herlev og Gentofte hospital</a></p><p><b>event</b>: <a href=\"http://medcomfhir.dk/ig/terminology/1.5.0/CodeSystem-medcom-messaging-eventCodes.html#medcom-messaging-eventCodes-hospital-notification-message\">MedComMessagingEventCodes: hospital-notification-message</a> (Hospital Notification Message)</p><h3>Destinations</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Extension</b></td><td><b>Endpoint</b></td><td><b>Receiver</b></td></tr><tr><td style=\"display: none\">*</td><td/><td><a href=\"https://sor2.sum.dsdn.dk/#id=953741000016009\">https://sor2.sum.dsdn.dk/#id=953741000016009</a></td><td><a href=\"Organization-95c682b6-2579-4867-bbf8-2309b96becaa.html\">Organization Plejecenter Herlev</a></td></tr></table><p><b>sender</b>: <a href=\"Organization-bebbaee3-7891-414d-a420-a057a72a4969.html\">Organization Hjerteafdelingen på Herlev og Gentofte hospital</a></p><h3>Sources</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Endpoint</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"https://sor2.sum.dsdn.dk/#id=265161000016000\">https://sor2.sum.dsdn.dk/#id=265161000016000</a></td></tr></table><p><b>focus</b>: <a href=\"Encounter-80e454b0-f910-412d-81d9-30f9a5b28483.html\">Encounter: status = in-progress; class = inpatient encounter (ActCode#IMP); period = 2026-03-01 12:00:00+0100 --&gt; (ongoing)</a></p></div>"
      },
      "extension" : [{
        "url" : "http://medcomfhir.dk/ig/hospitalnotification/StructureDefinition/medcom-messaging-reportOfAdmissionExtension",
        "valueBoolean" : true
      },
      {
        "url" : "http://medcomfhir.dk/ig/hospitalnotification/StructureDefinition/medcom-messaging-reportOfAdmissionRecipientExtension",
        "valueReference" : {
          "reference" : "Organization/bebbaee3-7891-414d-a420-a057a72a4969"
        }
      }],
      "eventCoding" : {
        "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-messaging-eventCodes",
        "code" : "hospital-notification-message"
      },
      "destination" : [{
        "extension" : [{
          "url" : "http://medcomfhir.dk/ig/messaging/StructureDefinition/medcom-messaging-destinationUseExtension",
          "valueCoding" : {
            "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-messaging-destinationUse",
            "code" : "primary"
          }
        }],
        "endpoint" : "https://sor2.sum.dsdn.dk/#id=953741000016009",
        "receiver" : {
          "reference" : "Organization/95c682b6-2579-4867-bbf8-2309b96becaa"
        }
      }],
      "sender" : {
        "reference" : "Organization/bebbaee3-7891-414d-a420-a057a72a4969"
      },
      "source" : {
        "endpoint" : "https://sor2.sum.dsdn.dk/#id=265161000016000"
      },
      "focus" : [{
        "reference" : "Encounter/80e454b0-f910-412d-81d9-30f9a5b28483"
      }]
    }
  },
  {
    "fullUrl" : "https://medcomfhir.dk/ig/hospitalnotification/Patient/f3bba9c9-cbd0-460f-aeeb-e3afcfed8993",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "f3bba9c9-cbd0-460f-aeeb-e3afcfed8993",
      "meta" : {
        "profile" : ["http://medcomfhir.dk/ig/core/StructureDefinition/medcom-core-patient"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_f3bba9c9-cbd0-460f-aeeb-e3afcfed8993\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient f3bba9c9-cbd0-460f-aeeb-e3afcfed8993</b></p><a name=\"f3bba9c9-cbd0-460f-aeeb-e3afcfed8993\"> </a><a name=\"hcf3bba9c9-cbd0-460f-aeeb-e3afcfed8993\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://medcomfhir.dk/ig/core/2.3.0/StructureDefinition-medcom-core-patient.html\">MedComCorePatient</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Elmer (official) (no stated gender), DoB Unknown ( urn:oid:1.2.208.176.1.2#DkCoreDanishCivilRegistrationSystem#2509479989)</p><hr/></div>"
      },
      "identifier" : [{
        "system" : "urn:oid:1.2.208.176.1.2",
        "value" : "2509479989"
      }],
      "name" : [{
        "use" : "official",
        "family" : "Elmer"
      }]
    }
  },
  {
    "fullUrl" : "https://medcomfhir.dk/ig/hospitalnotification/Encounter/80e454b0-f910-412d-81d9-30f9a5b28483",
    "resource" : {
      "resourceType" : "Encounter",
      "id" : "80e454b0-f910-412d-81d9-30f9a5b28483",
      "meta" : {
        "profile" : ["http://medcomfhir.dk/ig/hospitalnotification/StructureDefinition/medcom-hospitalNotification-encounter"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Encounter_80e454b0-f910-412d-81d9-30f9a5b28483\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Encounter 80e454b0-f910-412d-81d9-30f9a5b28483</b></p><a name=\"80e454b0-f910-412d-81d9-30f9a5b28483\"> </a><a name=\"hc80e454b0-f910-412d-81d9-30f9a5b28483\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-medcom-hospitalNotification-encounter.html\">MedComHospitalNotificationEncounter</a></p></div><p><b>status</b>: In Progress</p><p><b>class</b>: <a href=\"http://terminology.hl7.org/7.3.0/CodeSystem-v3-ActCode.html#v3-ActCode-IMP\">ActCode: IMP</a> (inpatient encounter)</p><p><b>subject</b>: <a href=\"Patient-f3bba9c9-cbd0-460f-aeeb-e3afcfed8993.html\">Elmer (official) (no stated gender), DoB Unknown ( urn:oid:1.2.208.176.1.2#DkCoreDanishCivilRegistrationSystem#2509479989)</a></p><p><b>episodeOfCare</b>: Identifier: <code>https://sor2.sum.dsdn.dk/#id=265161000016000</code>/04675bbd-c540-4545-924c-1fa79b64535c</p><p><b>period</b>: 2026-03-01 12:00:00+0100 --&gt; (ongoing)</p><p><b>serviceProvider</b>: <a href=\"Organization-bebbaee3-7891-414d-a420-a057a72a4969.html\">Organization Hjerteafdelingen på Herlev og Gentofte hospital</a></p></div>"
      },
      "status" : "in-progress",
      "class" : {
        "system" : "http://terminology.hl7.org/CodeSystem/v3-ActCode",
        "code" : "IMP"
      },
      "subject" : {
        "reference" : "Patient/f3bba9c9-cbd0-460f-aeeb-e3afcfed8993"
      },
      "episodeOfCare" : [{
        "identifier" : {
          "system" : "https://sor2.sum.dsdn.dk/#id=265161000016000",
          "value" : "04675bbd-c540-4545-924c-1fa79b64535c"
        }
      }],
      "period" : {
        "start" : "2026-03-01T12:00:00+01:00"
      },
      "serviceProvider" : {
        "reference" : "Organization/bebbaee3-7891-414d-a420-a057a72a4969"
      }
    }
  },
  {
    "fullUrl" : "https://medcomfhir.dk/ig/hospitalnotification/Organization/95c682b6-2579-4867-bbf8-2309b96becaa",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "95c682b6-2579-4867-bbf8-2309b96becaa",
      "meta" : {
        "profile" : ["http://medcomfhir.dk/ig/messaging/StructureDefinition/medcom-messaging-organization"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_95c682b6-2579-4867-bbf8-2309b96becaa\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization 95c682b6-2579-4867-bbf8-2309b96becaa</b></p><a name=\"95c682b6-2579-4867-bbf8-2309b96becaa\"> </a><a name=\"hc95c682b6-2579-4867-bbf8-2309b96becaa\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://medcomfhir.dk/ig/messaging/2.1.0/StructureDefinition-medcom-messaging-organization.html\">MedComMessagingOrganization</a></p></div><p><b>identifier</b>: <code>https://www.gs1.org/gln</code>/5790001348120, <code>urn:oid:1.2.208.176.1.1</code>/953741000016009</p><p><b>name</b>: Plejecenter Herlev</p></div>"
      },
      "identifier" : [{
        "system" : "https://www.gs1.org/gln",
        "value" : "5790001348120"
      },
      {
        "system" : "urn:oid:1.2.208.176.1.1",
        "value" : "953741000016009"
      }],
      "name" : "Plejecenter Herlev"
    }
  },
  {
    "fullUrl" : "https://medcomfhir.dk/ig/hospitalnotification/Organization/bebbaee3-7891-414d-a420-a057a72a4969",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "bebbaee3-7891-414d-a420-a057a72a4969",
      "meta" : {
        "profile" : ["http://medcomfhir.dk/ig/messaging/StructureDefinition/medcom-messaging-organization"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_bebbaee3-7891-414d-a420-a057a72a4969\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization bebbaee3-7891-414d-a420-a057a72a4969</b></p><a name=\"bebbaee3-7891-414d-a420-a057a72a4969\"> </a><a name=\"hcbebbaee3-7891-414d-a420-a057a72a4969\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://medcomfhir.dk/ig/messaging/2.1.0/StructureDefinition-medcom-messaging-organization.html\">MedComMessagingOrganization</a></p></div><p><b>identifier</b>: <code>https://www.gs1.org/gln</code>/5790000209354, <code>urn:oid:1.2.208.176.1.1</code>/265161000016000</p><p><b>name</b>: Hjerteafdelingen på Herlev og Gentofte hospital</p></div>"
      },
      "identifier" : [{
        "system" : "https://www.gs1.org/gln",
        "value" : "5790000209354"
      },
      {
        "system" : "urn:oid:1.2.208.176.1.1",
        "value" : "265161000016000"
      }],
      "name" : "Hjerteafdelingen på Herlev og Gentofte hospital"
    }
  },
  {
    "fullUrl" : "https://medcomfhir.dk/ig/hospitalnotification/Provenance/390da08b-6a5c-4cf1-8a92-b1e2a3788da4",
    "resource" : {
      "resourceType" : "Provenance",
      "id" : "390da08b-6a5c-4cf1-8a92-b1e2a3788da4",
      "meta" : {
        "profile" : ["http://medcomfhir.dk/ig/messaging/StructureDefinition/medcom-messaging-provenance"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Provenance_390da08b-6a5c-4cf1-8a92-b1e2a3788da4\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Provenance 390da08b-6a5c-4cf1-8a92-b1e2a3788da4</b></p><a name=\"390da08b-6a5c-4cf1-8a92-b1e2a3788da4\"> </a><a name=\"hc390da08b-6a5c-4cf1-8a92-b1e2a3788da4\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://medcomfhir.dk/ig/messaging/2.1.0/StructureDefinition-medcom-messaging-provenance.html\">MedComMessagingProvenance</a></p></div><p>Provenance for <a href=\"MessageHeader-fe400034-8a4b-4998-94f4-aef6840c647d.html\">MessageHeader: extension = true,-&gt;Organization Hjerteafdelingen på Herlev og Gentofte hospital; event[x] = Hospital Notification Message (MedComMessagingEventCodes#hospital-notification-message)</a></p><p>Summary</p><table class=\"grid\"><tr><td>Occurrence</td><td>2026-03-01 12:00:02+0100</td></tr><tr><td>Recorded</td><td>2026-03-01 12:00:02+0100</td></tr><tr><td>Activity</td><td><span title=\"Codes:{http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-messaging-activityCodes admit-inpatient}\">Start hospital stay - admitted</span></td></tr></table><p><b>Agents</b></p><table class=\"grid\"><tr><td><b>who</b></td></tr><tr><td><a href=\"Organization-bebbaee3-7891-414d-a420-a057a72a4969.html\">Organization Hjerteafdelingen på Herlev og Gentofte hospital</a></td></tr></table></div>"
      },
      "target" : [{
        "reference" : "MessageHeader/fe400034-8a4b-4998-94f4-aef6840c647d"
      }],
      "occurredDateTime" : "2026-03-01T12:00:02+01:00",
      "recorded" : "2026-03-01T12:00:02+01:00",
      "activity" : {
        "coding" : [{
          "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-messaging-activityCodes",
          "code" : "admit-inpatient"
        }]
      },
      "agent" : [{
        "who" : {
          "reference" : "Organization/bebbaee3-7891-414d-a420-a057a72a4969"
        }
      }]
    }
  }]
}

```
