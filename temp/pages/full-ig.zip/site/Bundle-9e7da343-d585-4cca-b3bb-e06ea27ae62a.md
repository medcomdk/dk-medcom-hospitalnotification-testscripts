# 9e7da343-d585-4cca-b3bb-e06ea27ae62a - HospitalNotification Testscripts v3.0.3

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **9e7da343-d585-4cca-b3bb-e06ea27ae62a**

## Bundle: 9e7da343-d585-4cca-b3bb-e06ea27ae62a



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "9e7da343-d585-4cca-b3bb-e06ea27ae62a",
  "meta" : {
    "profile" : ["http://medcomfhir.dk/ig/hospitalnotification/StructureDefinition/medcom-hospitalNotification-message"]
  },
  "type" : "message",
  "timestamp" : "2026-03-01T12:00:00+01:00",
  "entry" : [{
    "fullUrl" : "https://medcomfhir.dk/ig/hospitalnotification/MessageHeader/2ed179eb-69b8-4241-9183-3d4b15da9856",
    "resource" : {
      "resourceType" : "MessageHeader",
      "id" : "2ed179eb-69b8-4241-9183-3d4b15da9856",
      "meta" : {
        "profile" : ["http://medcomfhir.dk/ig/hospitalnotification/StructureDefinition/medcom-hospitalNotification-messageHeader"]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MessageHeader_2ed179eb-69b8-4241-9183-3d4b15da9856\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MessageHeader 2ed179eb-69b8-4241-9183-3d4b15da9856</b></p><a name=\"2ed179eb-69b8-4241-9183-3d4b15da9856\"> </a><a name=\"hc2ed179eb-69b8-4241-9183-3d4b15da9856\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-medcom-hospitalNotification-messageHeader.html\">MedComHospitalNotificationMessageHeader</a></p></div><p><b>MedComReportOfAdmissionExtension</b>: true</p><p><b>MedComReportOfAdmissionRecipientExtension</b>: <a href=\"Organization-267cc253-1acc-4e89-a490-2f9c63b34693.html\">Organization Hjerteafdelingen på Herlev og Gentofte hospital</a></p><p><b>event</b>: <a href=\"http://medcomfhir.dk/ig/terminology/1.5.0/CodeSystem-medcom-messaging-eventCodes.html#medcom-messaging-eventCodes-hospital-notification-message\">MedComMessagingEventCodes: hospital-notification-message</a> (Hospital Notification Message)</p><h3>Destinations</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Extension</b></td><td><b>Endpoint</b></td><td><b>Receiver</b></td></tr><tr><td style=\"display: none\">*</td><td/><td><a href=\"https://sor2.sum.dsdn.dk/#id=953741000016009\">https://sor2.sum.dsdn.dk/#id=953741000016009</a></td><td><a href=\"Organization-bd18a704-6d5f-47c3-8759-f47038e03edb.html\">Organization Plejecenter Herlev</a></td></tr></table><p><b>sender</b>: <a href=\"Organization-267cc253-1acc-4e89-a490-2f9c63b34693.html\">Organization Hjerteafdelingen på Herlev og Gentofte hospital</a></p><h3>Sources</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Endpoint</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"https://sor2.sum.dsdn.dk/#id=265161000016000\">https://sor2.sum.dsdn.dk/#id=265161000016000</a></td></tr></table><p><b>focus</b>: <a href=\"Encounter-59a01e8f-87bb-4f6e-9036-a37f8922318c.html\">Encounter: status = in-progress; class = inpatient encounter (ActCode#IMP); period = 2026-03-01 12:00:00+0100 --&gt; (ongoing)</a></p></div>"
      },
      "extension" : [{
        "url" : "http://medcomfhir.dk/ig/hospitalnotification/StructureDefinition/medcom-messaging-reportOfAdmissionExtension",
        "valueBoolean" : true
      },
      {
        "url" : "http://medcomfhir.dk/ig/hospitalnotification/StructureDefinition/medcom-messaging-reportOfAdmissionRecipientExtension",
        "valueReference" : {
          "reference" : "Organization/267cc253-1acc-4e89-a490-2f9c63b34693"
        }
      }],
      "eventCoding" : {
        "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-messaging-eventCodes",
        "code" : "hospital-notification-message"
      },
      "destination" : [{
        "extension" : [{
          "url" : "http://medcomfhir.dk/ig/messaging/StructureDefinition/medcom-messaging-destinationUseExtension",
          "valueCoding" : {
            "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-messaging-destinationUse",
            "code" : "primary"
          }
        }],
        "endpoint" : "https://sor2.sum.dsdn.dk/#id=953741000016009",
        "receiver" : {
          "reference" : "Organization/bd18a704-6d5f-47c3-8759-f47038e03edb"
        }
      }],
      "sender" : {
        "reference" : "Organization/267cc253-1acc-4e89-a490-2f9c63b34693"
      },
      "source" : {
        "endpoint" : "https://sor2.sum.dsdn.dk/#id=265161000016000"
      },
      "focus" : [{
        "reference" : "Encounter/59a01e8f-87bb-4f6e-9036-a37f8922318c"
      }]
    }
  },
  {
    "fullUrl" : "https://medcomfhir.dk/ig/hospitalnotification/Patient/b9756955-e933-4133-8083-74ab2aa51a23",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "b9756955-e933-4133-8083-74ab2aa51a23",
      "meta" : {
        "profile" : ["http://medcomfhir.dk/ig/core/StructureDefinition/medcom-core-patient"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_b9756955-e933-4133-8083-74ab2aa51a23\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient b9756955-e933-4133-8083-74ab2aa51a23</b></p><a name=\"b9756955-e933-4133-8083-74ab2aa51a23\"> </a><a name=\"hcb9756955-e933-4133-8083-74ab2aa51a23\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://medcomfhir.dk/ig/core/2.3.0/StructureDefinition-medcom-core-patient.html\">MedComCorePatient</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Elmer (official) (no stated gender), DoB Unknown ( urn:oid:1.2.208.176.1.2#DkCoreDanishCivilRegistrationSystem#2509479989)</p><hr/></div>"
      },
      "identifier" : [{
        "system" : "urn:oid:1.2.208.176.1.2",
        "value" : "2509479989"
      }],
      "name" : [{
        "use" : "official",
        "family" : "Elmer"
      }]
    }
  },
  {
    "fullUrl" : "https://medcomfhir.dk/ig/hospitalnotification/Encounter/59a01e8f-87bb-4f6e-9036-a37f8922318c",
    "resource" : {
      "resourceType" : "Encounter",
      "id" : "59a01e8f-87bb-4f6e-9036-a37f8922318c",
      "meta" : {
        "profile" : ["http://medcomfhir.dk/ig/hospitalnotification/StructureDefinition/medcom-hospitalNotification-encounter"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Encounter_59a01e8f-87bb-4f6e-9036-a37f8922318c\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Encounter 59a01e8f-87bb-4f6e-9036-a37f8922318c</b></p><a name=\"59a01e8f-87bb-4f6e-9036-a37f8922318c\"> </a><a name=\"hc59a01e8f-87bb-4f6e-9036-a37f8922318c\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-medcom-hospitalNotification-encounter.html\">MedComHospitalNotificationEncounter</a></p></div><p><b>status</b>: In Progress</p><p><b>class</b>: <a href=\"http://terminology.hl7.org/7.3.0/CodeSystem-v3-ActCode.html#v3-ActCode-IMP\">ActCode: IMP</a> (inpatient encounter)</p><p><b>subject</b>: <a href=\"Patient-b9756955-e933-4133-8083-74ab2aa51a23.html\">Elmer (official) (no stated gender), DoB Unknown ( urn:oid:1.2.208.176.1.2#DkCoreDanishCivilRegistrationSystem#2509479989)</a></p><p><b>episodeOfCare</b>: Identifier: <code>https://www.esundhed.dk/Registre/Landspatientregisteret</code>/urn:uuid:15d54a58-507e-40ec-b5ce-9c4df248d842</p><p><b>period</b>: 2026-03-01 12:00:00+0100 --&gt; (ongoing)</p><p><b>serviceProvider</b>: <a href=\"Organization-267cc253-1acc-4e89-a490-2f9c63b34693.html\">Organization Hjerteafdelingen på Herlev og Gentofte hospital</a></p></div>"
      },
      "status" : "in-progress",
      "class" : {
        "system" : "http://terminology.hl7.org/CodeSystem/v3-ActCode",
        "code" : "IMP"
      },
      "subject" : {
        "reference" : "Patient/b9756955-e933-4133-8083-74ab2aa51a23"
      },
      "episodeOfCare" : [{
        "identifier" : {
          "system" : "https://www.esundhed.dk/Registre/Landspatientregisteret",
          "value" : "urn:uuid:15d54a58-507e-40ec-b5ce-9c4df248d842"
        }
      }],
      "period" : {
        "start" : "2026-03-01T12:00:00+01:00"
      },
      "serviceProvider" : {
        "reference" : "Organization/267cc253-1acc-4e89-a490-2f9c63b34693"
      }
    }
  },
  {
    "fullUrl" : "https://medcomfhir.dk/ig/hospitalnotification/Organization/bd18a704-6d5f-47c3-8759-f47038e03edb",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "bd18a704-6d5f-47c3-8759-f47038e03edb",
      "meta" : {
        "profile" : ["http://medcomfhir.dk/ig/messaging/StructureDefinition/medcom-messaging-organization"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_bd18a704-6d5f-47c3-8759-f47038e03edb\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization bd18a704-6d5f-47c3-8759-f47038e03edb</b></p><a name=\"bd18a704-6d5f-47c3-8759-f47038e03edb\"> </a><a name=\"hcbd18a704-6d5f-47c3-8759-f47038e03edb\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://medcomfhir.dk/ig/messaging/2.1.0/StructureDefinition-medcom-messaging-organization.html\">MedComMessagingOrganization</a></p></div><p><b>identifier</b>: <code>https://www.gs1.org/gln</code>/5790001348120, <code>urn:oid:1.2.208.176.1.1</code>/953741000016009</p><p><b>name</b>: Plejecenter Herlev</p></div>"
      },
      "identifier" : [{
        "system" : "https://www.gs1.org/gln",
        "value" : "5790001348120"
      },
      {
        "system" : "urn:oid:1.2.208.176.1.1",
        "value" : "953741000016009"
      }],
      "name" : "Plejecenter Herlev"
    }
  },
  {
    "fullUrl" : "https://medcomfhir.dk/ig/hospitalnotification/Organization/267cc253-1acc-4e89-a490-2f9c63b34693",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "267cc253-1acc-4e89-a490-2f9c63b34693",
      "meta" : {
        "profile" : ["http://medcomfhir.dk/ig/messaging/StructureDefinition/medcom-messaging-organization"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_267cc253-1acc-4e89-a490-2f9c63b34693\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization 267cc253-1acc-4e89-a490-2f9c63b34693</b></p><a name=\"267cc253-1acc-4e89-a490-2f9c63b34693\"> </a><a name=\"hc267cc253-1acc-4e89-a490-2f9c63b34693\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://medcomfhir.dk/ig/messaging/2.1.0/StructureDefinition-medcom-messaging-organization.html\">MedComMessagingOrganization</a></p></div><p><b>identifier</b>: <code>https://www.gs1.org/gln</code>/5790000209354, <code>urn:oid:1.2.208.176.1.1</code>/265161000016000</p><p><b>name</b>: Hjerteafdelingen på Herlev og Gentofte hospital</p></div>"
      },
      "identifier" : [{
        "system" : "https://www.gs1.org/gln",
        "value" : "5790000209354"
      },
      {
        "system" : "urn:oid:1.2.208.176.1.1",
        "value" : "265161000016000"
      }],
      "name" : "Hjerteafdelingen på Herlev og Gentofte hospital"
    }
  },
  {
    "fullUrl" : "https://medcomfhir.dk/ig/hospitalnotification/Provenance/5f6ad22a-0f14-44bc-bafa-71e7ddd4d6af",
    "resource" : {
      "resourceType" : "Provenance",
      "id" : "5f6ad22a-0f14-44bc-bafa-71e7ddd4d6af",
      "meta" : {
        "profile" : ["http://medcomfhir.dk/ig/messaging/StructureDefinition/medcom-messaging-provenance"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Provenance_5f6ad22a-0f14-44bc-bafa-71e7ddd4d6af\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Provenance 5f6ad22a-0f14-44bc-bafa-71e7ddd4d6af</b></p><a name=\"5f6ad22a-0f14-44bc-bafa-71e7ddd4d6af\"> </a><a name=\"hc5f6ad22a-0f14-44bc-bafa-71e7ddd4d6af\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://medcomfhir.dk/ig/messaging/2.1.0/StructureDefinition-medcom-messaging-provenance.html\">MedComMessagingProvenance</a></p></div><p>Provenance for <a href=\"MessageHeader-2ed179eb-69b8-4241-9183-3d4b15da9856.html\">MessageHeader: extension = true,-&gt;Organization Hjerteafdelingen på Herlev og Gentofte hospital; event[x] = Hospital Notification Message (MedComMessagingEventCodes#hospital-notification-message)</a></p><p>Summary</p><table class=\"grid\"><tr><td>Occurrence</td><td>2026-03-01 12:00:00+0100</td></tr><tr><td>Recorded</td><td>2026-03-01 12:00:00+0100</td></tr><tr><td>Activity</td><td><span title=\"Codes:{http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-messaging-activityCodes admit-inpatient}\">Start hospital stay - admitted</span></td></tr></table><p><b>Agents</b></p><table class=\"grid\"><tr><td><b>who</b></td></tr><tr><td><a href=\"Organization-267cc253-1acc-4e89-a490-2f9c63b34693.html\">Organization Hjerteafdelingen på Herlev og Gentofte hospital</a></td></tr></table></div>"
      },
      "target" : [{
        "reference" : "MessageHeader/2ed179eb-69b8-4241-9183-3d4b15da9856"
      }],
      "occurredDateTime" : "2026-03-01T12:00:00+01:00",
      "recorded" : "2026-03-01T12:00:00+01:00",
      "activity" : {
        "coding" : [{
          "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-messaging-activityCodes",
          "code" : "admit-inpatient"
        }]
      },
      "agent" : [{
        "who" : {
          "reference" : "Organization/267cc253-1acc-4e89-a490-2f9c63b34693"
        }
      }]
    }
  }]
}

```
