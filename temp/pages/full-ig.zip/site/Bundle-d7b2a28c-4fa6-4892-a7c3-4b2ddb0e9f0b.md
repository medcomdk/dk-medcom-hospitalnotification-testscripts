# d7b2a28c-4fa6-4892-a7c3-4b2ddb0e9f0b - HospitalNotification Testscripts v3.0.3

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **d7b2a28c-4fa6-4892-a7c3-4b2ddb0e9f0b**

## Bundle: d7b2a28c-4fa6-4892-a7c3-4b2ddb0e9f0b



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "d7b2a28c-4fa6-4892-a7c3-4b2ddb0e9f0b",
  "meta" : {
    "profile" : ["http://medcomfhir.dk/ig/hospitalnotification/StructureDefinition/medcom-hospitalNotification-message"]
  },
  "type" : "message",
  "timestamp" : "2026-03-05T15:30:02+01:00",
  "entry" : [{
    "fullUrl" : "https://medcomfhir.dk/ig/hospitalnotification/MessageHeader/6f0df012-296e-49dc-bc42-0c57dbe47186",
    "resource" : {
      "resourceType" : "MessageHeader",
      "id" : "6f0df012-296e-49dc-bc42-0c57dbe47186",
      "meta" : {
        "profile" : ["http://medcomfhir.dk/ig/hospitalnotification/StructureDefinition/medcom-hospitalNotification-messageHeader"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MessageHeader_6f0df012-296e-49dc-bc42-0c57dbe47186\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MessageHeader 6f0df012-296e-49dc-bc42-0c57dbe47186</b></p><a name=\"6f0df012-296e-49dc-bc42-0c57dbe47186\"> </a><a name=\"hc6f0df012-296e-49dc-bc42-0c57dbe47186\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-medcom-hospitalNotification-messageHeader.html\">MedComHospitalNotificationMessageHeader</a></p></div><p><b>event</b>: <a href=\"http://medcomfhir.dk/ig/terminology/1.5.0/CodeSystem-medcom-messaging-eventCodes.html#medcom-messaging-eventCodes-hospital-notification-message\">MedComMessagingEventCodes: hospital-notification-message</a> (Hospital Notification Message)</p><h3>Destinations</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Extension</b></td><td><b>Endpoint</b></td><td><b>Receiver</b></td></tr><tr><td style=\"display: none\">*</td><td/><td><a href=\"https://sor2.sum.dsdn.dk/#id=953741000016009\">https://sor2.sum.dsdn.dk/#id=953741000016009</a></td><td><a href=\"Organization-c825bf0c-7c82-4cee-a04f-72558a51f143.html\">Organization Plejecenter Herlev</a></td></tr></table><p><b>sender</b>: <a href=\"Organization-daa6be45-276d-4c4b-92ee-89a3ae0c0905.html\">Organization Hjerteafdelingen på Herlev og Gentofte hospital</a></p><h3>Sources</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Endpoint</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"https://sor2.sum.dsdn.dk/#id=265161000016000\">https://sor2.sum.dsdn.dk/#id=265161000016000</a></td></tr></table><p><b>focus</b>: <a href=\"Encounter-2dc6f125-bd58-46c3-b1b7-192038507d02.html\">Encounter: extension = 2026-03-03 14:00:10+0100 --&gt; 2026-03-05 15:30:00+0100; status = in-progress; class = inpatient encounter (ActCode#IMP); period = 2026-03-01 12:00:00+0100 --&gt; (ongoing)</a></p></div>"
      },
      "eventCoding" : {
        "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-messaging-eventCodes",
        "code" : "hospital-notification-message"
      },
      "destination" : [{
        "extension" : [{
          "url" : "http://medcomfhir.dk/ig/messaging/StructureDefinition/medcom-messaging-destinationUseExtension",
          "valueCoding" : {
            "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-messaging-destinationUse",
            "code" : "primary"
          }
        }],
        "endpoint" : "https://sor2.sum.dsdn.dk/#id=953741000016009",
        "receiver" : {
          "reference" : "Organization/c825bf0c-7c82-4cee-a04f-72558a51f143"
        }
      }],
      "sender" : {
        "reference" : "Organization/daa6be45-276d-4c4b-92ee-89a3ae0c0905"
      },
      "source" : {
        "endpoint" : "https://sor2.sum.dsdn.dk/#id=265161000016000"
      },
      "focus" : [{
        "reference" : "Encounter/2dc6f125-bd58-46c3-b1b7-192038507d02"
      }]
    }
  },
  {
    "fullUrl" : "https://medcomfhir.dk/ig/hospitalnotification/Patient/e7714040-f507-4d6f-9629-7bf7e75d60aa",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "e7714040-f507-4d6f-9629-7bf7e75d60aa",
      "meta" : {
        "profile" : ["http://medcomfhir.dk/ig/core/StructureDefinition/medcom-core-patient"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_e7714040-f507-4d6f-9629-7bf7e75d60aa\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient e7714040-f507-4d6f-9629-7bf7e75d60aa</b></p><a name=\"e7714040-f507-4d6f-9629-7bf7e75d60aa\"> </a><a name=\"hce7714040-f507-4d6f-9629-7bf7e75d60aa\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://medcomfhir.dk/ig/core/2.3.0/StructureDefinition-medcom-core-patient.html\">MedComCorePatient</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Elmer (official) (no stated gender), DoB Unknown ( urn:oid:1.2.208.176.1.2#DkCoreDanishCivilRegistrationSystem#2509479989)</p><hr/></div>"
      },
      "identifier" : [{
        "system" : "urn:oid:1.2.208.176.1.2",
        "value" : "2509479989"
      }],
      "name" : [{
        "use" : "official",
        "family" : "Elmer"
      }]
    }
  },
  {
    "fullUrl" : "https://medcomfhir.dk/ig/hospitalnotification/Encounter/2dc6f125-bd58-46c3-b1b7-192038507d02",
    "resource" : {
      "resourceType" : "Encounter",
      "id" : "2dc6f125-bd58-46c3-b1b7-192038507d02",
      "meta" : {
        "profile" : ["http://medcomfhir.dk/ig/hospitalnotification/StructureDefinition/medcom-hospitalNotification-encounter"]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Encounter_2dc6f125-bd58-46c3-b1b7-192038507d02\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Encounter 2dc6f125-bd58-46c3-b1b7-192038507d02</b></p><a name=\"2dc6f125-bd58-46c3-b1b7-192038507d02\"> </a><a name=\"hc2dc6f125-bd58-46c3-b1b7-192038507d02\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-medcom-hospitalNotification-encounter.html\">MedComHospitalNotificationEncounter</a></p></div><p><b>MedComHospitalNotificationLeavePeriodExtension</b>: 2026-03-03 14:00:10+0100 --&gt; 2026-03-05 15:30:00+0100</p><p><b>status</b>: In Progress</p><p><b>class</b>: <a href=\"http://terminology.hl7.org/7.3.0/CodeSystem-v3-ActCode.html#v3-ActCode-IMP\">ActCode: IMP</a> (inpatient encounter)</p><p><b>subject</b>: <a href=\"Patient-e7714040-f507-4d6f-9629-7bf7e75d60aa.html\">Elmer (official) (no stated gender), DoB Unknown ( urn:oid:1.2.208.176.1.2#DkCoreDanishCivilRegistrationSystem#2509479989)</a></p><p><b>episodeOfCare</b>: Identifier: <code>https://sor2.sum.dsdn.dk/#id=265161000016000</code>/04675bbd-c540-4545-924c-1fa79b64535c</p><p><b>period</b>: 2026-03-01 12:00:00+0100 --&gt; (ongoing)</p><p><b>serviceProvider</b>: <a href=\"Organization-daa6be45-276d-4c4b-92ee-89a3ae0c0905.html\">Organization Hjerteafdelingen på Herlev og Gentofte hospital</a></p></div>"
      },
      "extension" : [{
        "url" : "http://medcomfhir.dk/ig/hospitalnotification/StructureDefinition/medcom-hospitalnotifiation-leave-period-extension",
        "valuePeriod" : {
          "start" : "2026-03-03T14:00:10+01:00",
          "end" : "2026-03-05T15:30:00+01:00"
        }
      }],
      "status" : "in-progress",
      "class" : {
        "system" : "http://terminology.hl7.org/CodeSystem/v3-ActCode",
        "code" : "IMP"
      },
      "subject" : {
        "reference" : "Patient/e7714040-f507-4d6f-9629-7bf7e75d60aa"
      },
      "episodeOfCare" : [{
        "identifier" : {
          "system" : "https://sor2.sum.dsdn.dk/#id=265161000016000",
          "value" : "04675bbd-c540-4545-924c-1fa79b64535c"
        }
      }],
      "period" : {
        "start" : "2026-03-01T12:00:00+01:00"
      },
      "serviceProvider" : {
        "reference" : "Organization/daa6be45-276d-4c4b-92ee-89a3ae0c0905"
      }
    }
  },
  {
    "fullUrl" : "https://medcomfhir.dk/ig/hospitalnotification/Organization/c825bf0c-7c82-4cee-a04f-72558a51f143",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "c825bf0c-7c82-4cee-a04f-72558a51f143",
      "meta" : {
        "profile" : ["http://medcomfhir.dk/ig/messaging/StructureDefinition/medcom-messaging-organization"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_c825bf0c-7c82-4cee-a04f-72558a51f143\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization c825bf0c-7c82-4cee-a04f-72558a51f143</b></p><a name=\"c825bf0c-7c82-4cee-a04f-72558a51f143\"> </a><a name=\"hcc825bf0c-7c82-4cee-a04f-72558a51f143\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://medcomfhir.dk/ig/messaging/2.1.0/StructureDefinition-medcom-messaging-organization.html\">MedComMessagingOrganization</a></p></div><p><b>identifier</b>: <code>https://www.gs1.org/gln</code>/5790001348120, <code>urn:oid:1.2.208.176.1.1</code>/953741000016009</p><p><b>name</b>: Plejecenter Herlev</p></div>"
      },
      "identifier" : [{
        "system" : "https://www.gs1.org/gln",
        "value" : "5790001348120"
      },
      {
        "system" : "urn:oid:1.2.208.176.1.1",
        "value" : "953741000016009"
      }],
      "name" : "Plejecenter Herlev"
    }
  },
  {
    "fullUrl" : "https://medcomfhir.dk/ig/hospitalnotification/Organization/daa6be45-276d-4c4b-92ee-89a3ae0c0905",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "daa6be45-276d-4c4b-92ee-89a3ae0c0905",
      "meta" : {
        "profile" : ["http://medcomfhir.dk/ig/messaging/StructureDefinition/medcom-messaging-organization"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_daa6be45-276d-4c4b-92ee-89a3ae0c0905\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization daa6be45-276d-4c4b-92ee-89a3ae0c0905</b></p><a name=\"daa6be45-276d-4c4b-92ee-89a3ae0c0905\"> </a><a name=\"hcdaa6be45-276d-4c4b-92ee-89a3ae0c0905\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://medcomfhir.dk/ig/messaging/2.1.0/StructureDefinition-medcom-messaging-organization.html\">MedComMessagingOrganization</a></p></div><p><b>identifier</b>: <code>https://www.gs1.org/gln</code>/5790000209354, <code>urn:oid:1.2.208.176.1.1</code>/265161000016000</p><p><b>name</b>: Hjerteafdelingen på Herlev og Gentofte hospital</p></div>"
      },
      "identifier" : [{
        "system" : "https://www.gs1.org/gln",
        "value" : "5790000209354"
      },
      {
        "system" : "urn:oid:1.2.208.176.1.1",
        "value" : "265161000016000"
      }],
      "name" : "Hjerteafdelingen på Herlev og Gentofte hospital"
    }
  },
  {
    "fullUrl" : "https://medcomfhir.dk/ig/hospitalnotification/Provenance/d9caec36-0fbf-4004-949d-aaff168a5580",
    "resource" : {
      "resourceType" : "Provenance",
      "id" : "d9caec36-0fbf-4004-949d-aaff168a5580",
      "meta" : {
        "profile" : ["http://medcomfhir.dk/ig/messaging/StructureDefinition/medcom-messaging-provenance"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Provenance_d9caec36-0fbf-4004-949d-aaff168a5580\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Provenance d9caec36-0fbf-4004-949d-aaff168a5580</b></p><a name=\"d9caec36-0fbf-4004-949d-aaff168a5580\"> </a><a name=\"hcd9caec36-0fbf-4004-949d-aaff168a5580\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://medcomfhir.dk/ig/messaging/2.1.0/StructureDefinition-medcom-messaging-provenance.html\">MedComMessagingProvenance</a></p></div><p>Provenance for <a href=\"MessageHeader/b9b4818e-02de-4cc4-b418-d20cbc399006\">MessageHeader/b9b4818e-02de-4cc4-b418-d20cbc399006</a></p><p>Summary</p><table class=\"grid\"><tr><td>Occurrence</td><td>2026-03-01 12:00:02+0100</td></tr><tr><td>Recorded</td><td>2026-03-01 12:00:02+0100</td></tr><tr><td>Activity</td><td><span title=\"Codes:{http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-messaging-activityCodes admit-inpatient}\">Start hospital stay - admitted</span></td></tr></table><p><b>Agents</b></p><table class=\"grid\"><tr><td><b>who</b></td></tr><tr><td><a href=\"Organization-daa6be45-276d-4c4b-92ee-89a3ae0c0905.html\">Organization Hjerteafdelingen på Herlev og Gentofte hospital</a></td></tr></table></div>"
      },
      "target" : [{
        "reference" : "MessageHeader/b9b4818e-02de-4cc4-b418-d20cbc399006"
      }],
      "occurredDateTime" : "2026-03-01T12:00:02+01:00",
      "recorded" : "2026-03-01T12:00:02+01:00",
      "activity" : {
        "coding" : [{
          "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-messaging-activityCodes",
          "code" : "admit-inpatient"
        }]
      },
      "agent" : [{
        "who" : {
          "reference" : "Organization/daa6be45-276d-4c4b-92ee-89a3ae0c0905"
        }
      }]
    }
  },
  {
    "fullUrl" : "https://medcomfhir.dk/ig/hospitalnotification/Provenance/78ef5d47-1c07-472a-a680-ee7852566835",
    "resource" : {
      "resourceType" : "Provenance",
      "id" : "78ef5d47-1c07-472a-a680-ee7852566835",
      "meta" : {
        "profile" : ["http://medcomfhir.dk/ig/messaging/StructureDefinition/medcom-messaging-provenance"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Provenance_78ef5d47-1c07-472a-a680-ee7852566835\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Provenance 78ef5d47-1c07-472a-a680-ee7852566835</b></p><a name=\"78ef5d47-1c07-472a-a680-ee7852566835\"> </a><a name=\"hc78ef5d47-1c07-472a-a680-ee7852566835\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://medcomfhir.dk/ig/messaging/2.1.0/StructureDefinition-medcom-messaging-provenance.html\">MedComMessagingProvenance</a></p></div><p>Provenance for <a href=\"MessageHeader/e563a2b2-bf92-4b13-bbd2-0a021a399006\">MessageHeader/e563a2b2-bf92-4b13-bbd2-0a021a399006</a></p><p>Summary</p><table class=\"grid\"><tr><td>Occurrence</td><td>2026-03-03 14:00:12+0100</td></tr><tr><td>Recorded</td><td>2026-03-03 14:00:12+0100</td></tr><tr><td>Activity</td><td><span title=\"Codes:{http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-messaging-activityCodes start-leave-inpatient}\">Start leave</span></td></tr></table><p><b>Agents</b></p><table class=\"grid\"><tr><td><b>who</b></td></tr><tr><td><a href=\"Organization-daa6be45-276d-4c4b-92ee-89a3ae0c0905.html\">Organization Hjerteafdelingen på Herlev og Gentofte hospital</a></td></tr></table></div>"
      },
      "target" : [{
        "reference" : "MessageHeader/e563a2b2-bf92-4b13-bbd2-0a021a399006"
      }],
      "occurredDateTime" : "2026-03-03T14:00:12+01:00",
      "recorded" : "2026-03-03T14:00:12+01:00",
      "activity" : {
        "coding" : [{
          "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-messaging-activityCodes",
          "code" : "start-leave-inpatient"
        }]
      },
      "agent" : [{
        "who" : {
          "reference" : "Organization/daa6be45-276d-4c4b-92ee-89a3ae0c0905"
        }
      }],
      "entity" : [{
        "role" : "revision",
        "what" : {
          "reference" : "MessageHeader/b9b4818e-02de-4cc4-b418-d20cbc399006"
        }
      }]
    }
  },
  {
    "fullUrl" : "https://medcomfhir.dk/ig/hospitalnotification/Provenance/c211b0a9-0efc-4965-8582-4f52244c5e98",
    "resource" : {
      "resourceType" : "Provenance",
      "id" : "c211b0a9-0efc-4965-8582-4f52244c5e98",
      "meta" : {
        "profile" : ["http://medcomfhir.dk/ig/messaging/StructureDefinition/medcom-messaging-provenance"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Provenance_c211b0a9-0efc-4965-8582-4f52244c5e98\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Provenance c211b0a9-0efc-4965-8582-4f52244c5e98</b></p><a name=\"c211b0a9-0efc-4965-8582-4f52244c5e98\"> </a><a name=\"hcc211b0a9-0efc-4965-8582-4f52244c5e98\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://medcomfhir.dk/ig/messaging/2.1.0/StructureDefinition-medcom-messaging-provenance.html\">MedComMessagingProvenance</a></p></div><p>Provenance for <a href=\"MessageHeader-6f0df012-296e-49dc-bc42-0c57dbe47186.html\">MessageHeader: event[x] = Hospital Notification Message (MedComMessagingEventCodes#hospital-notification-message)</a></p><p>Summary</p><table class=\"grid\"><tr><td>Occurrence</td><td>2026-03-05 15:30:02+0100</td></tr><tr><td>Recorded</td><td>2026-03-05 15:30:02+0100</td></tr><tr><td>Activity</td><td><span title=\"Codes:{http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-messaging-activityCodes end-leave-inpatient}\">End leave</span></td></tr></table><p><b>Agents</b></p><table class=\"grid\"><tr><td><b>who</b></td></tr><tr><td><a href=\"Organization-daa6be45-276d-4c4b-92ee-89a3ae0c0905.html\">Organization Hjerteafdelingen på Herlev og Gentofte hospital</a></td></tr></table></div>"
      },
      "target" : [{
        "reference" : "MessageHeader/6f0df012-296e-49dc-bc42-0c57dbe47186"
      }],
      "occurredDateTime" : "2026-03-05T15:30:02+01:00",
      "recorded" : "2026-03-05T15:30:02+01:00",
      "activity" : {
        "coding" : [{
          "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-messaging-activityCodes",
          "code" : "end-leave-inpatient"
        }]
      },
      "agent" : [{
        "who" : {
          "reference" : "Organization/daa6be45-276d-4c4b-92ee-89a3ae0c0905"
        }
      }],
      "entity" : [{
        "role" : "revision",
        "what" : {
          "reference" : "MessageHeader/e563a2b2-bf92-4b13-bbd2-0a021a399006"
        }
      }]
    }
  }]
}

```
