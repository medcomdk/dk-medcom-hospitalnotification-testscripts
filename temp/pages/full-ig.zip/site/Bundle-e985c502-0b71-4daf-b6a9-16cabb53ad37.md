# e985c502-0b71-4daf-b6a9-16cabb53ad37 - HospitalNotification Testscripts v3.0.3

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **e985c502-0b71-4daf-b6a9-16cabb53ad37**

## Bundle: e985c502-0b71-4daf-b6a9-16cabb53ad37



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "e985c502-0b71-4daf-b6a9-16cabb53ad37",
  "meta" : {
    "profile" : ["http://medcomfhir.dk/ig/hospitalnotification/StructureDefinition/medcom-hospitalNotification-message"]
  },
  "type" : "message",
  "timestamp" : "2026-02-28T10:00:06+01:00",
  "entry" : [{
    "fullUrl" : "https://medcomfhir.dk/ig/hospitalnotification/MessageHeader/e0c738da-480c-4f64-97f8-d4479a47b9f5",
    "resource" : {
      "resourceType" : "MessageHeader",
      "id" : "e0c738da-480c-4f64-97f8-d4479a47b9f5",
      "meta" : {
        "profile" : ["http://medcomfhir.dk/ig/hospitalnotification/StructureDefinition/medcom-hospitalNotification-messageHeader"]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MessageHeader_e0c738da-480c-4f64-97f8-d4479a47b9f5\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MessageHeader e0c738da-480c-4f64-97f8-d4479a47b9f5</b></p><a name=\"e0c738da-480c-4f64-97f8-d4479a47b9f5\"> </a><a name=\"hce0c738da-480c-4f64-97f8-d4479a47b9f5\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-medcom-hospitalNotification-messageHeader.html\">MedComHospitalNotificationMessageHeader</a></p></div><p><b>MedComReportOfAdmissionExtension</b>: true</p><p><b>MedComReportOfAdmissionRecipientExtension</b>: <a href=\"Organization-41767586-090e-4242-bf50-0dfcaf8d80e0.html\">Organization Hjerteafdelingen på Herlev og Gentofte hospital</a></p><p><b>event</b>: <a href=\"http://medcomfhir.dk/ig/terminology/1.5.0/CodeSystem-medcom-messaging-eventCodes.html#medcom-messaging-eventCodes-hospital-notification-message\">MedComMessagingEventCodes: hospital-notification-message</a> (Hospital Notification Message)</p><h3>Destinations</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Extension</b></td><td><b>Endpoint</b></td><td><b>Receiver</b></td></tr><tr><td style=\"display: none\">*</td><td/><td><a href=\"https://sor2.sum.dsdn.dk/#id=953741000016009\">https://sor2.sum.dsdn.dk/#id=953741000016009</a></td><td><a href=\"Organization-a3c6c488-9f80-4ae3-8c88-942053ca9234.html\">Organization Plejecenter Herlev</a></td></tr></table><p><b>sender</b>: <a href=\"Organization-41767586-090e-4242-bf50-0dfcaf8d80e0.html\">Organization Hjerteafdelingen på Herlev og Gentofte hospital</a></p><h3>Sources</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Endpoint</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"https://sor2.sum.dsdn.dk/#id=265161000016000\">https://sor2.sum.dsdn.dk/#id=265161000016000</a></td></tr></table><p><b>focus</b>: <a href=\"Encounter-7c08cb56-eb80-4979-855c-d8d75da9b01a.html\">Encounter: status = in-progress; class = emergency (ActCode#EMER); period = 2026-02-28 10:00:04+0100 --&gt; (ongoing)</a></p></div>"
      },
      "extension" : [{
        "url" : "http://medcomfhir.dk/ig/hospitalnotification/StructureDefinition/medcom-messaging-reportOfAdmissionExtension",
        "valueBoolean" : true
      },
      {
        "url" : "http://medcomfhir.dk/ig/hospitalnotification/StructureDefinition/medcom-messaging-reportOfAdmissionRecipientExtension",
        "valueReference" : {
          "reference" : "Organization/41767586-090e-4242-bf50-0dfcaf8d80e0"
        }
      }],
      "eventCoding" : {
        "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-messaging-eventCodes",
        "code" : "hospital-notification-message"
      },
      "destination" : [{
        "extension" : [{
          "url" : "http://medcomfhir.dk/ig/messaging/StructureDefinition/medcom-messaging-destinationUseExtension",
          "valueCoding" : {
            "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-messaging-destinationUse",
            "code" : "primary"
          }
        }],
        "endpoint" : "https://sor2.sum.dsdn.dk/#id=953741000016009",
        "receiver" : {
          "reference" : "Organization/a3c6c488-9f80-4ae3-8c88-942053ca9234"
        }
      }],
      "sender" : {
        "reference" : "Organization/41767586-090e-4242-bf50-0dfcaf8d80e0"
      },
      "source" : {
        "endpoint" : "https://sor2.sum.dsdn.dk/#id=265161000016000"
      },
      "focus" : [{
        "reference" : "Encounter/7c08cb56-eb80-4979-855c-d8d75da9b01a"
      }]
    }
  },
  {
    "fullUrl" : "https://medcomfhir.dk/ig/hospitalnotification/Patient/34bff467-2813-42ac-a928-220a8433dfa9",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "34bff467-2813-42ac-a928-220a8433dfa9",
      "meta" : {
        "profile" : ["http://medcomfhir.dk/ig/core/StructureDefinition/medcom-core-patient"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_34bff467-2813-42ac-a928-220a8433dfa9\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient 34bff467-2813-42ac-a928-220a8433dfa9</b></p><a name=\"34bff467-2813-42ac-a928-220a8433dfa9\"> </a><a name=\"hc34bff467-2813-42ac-a928-220a8433dfa9\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://medcomfhir.dk/ig/core/2.3.0/StructureDefinition-medcom-core-patient.html\">MedComCorePatient</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Elmer (official) (no stated gender), DoB Unknown ( urn:oid:1.2.208.176.1.2#DkCoreDanishCivilRegistrationSystem#2509479989)</p><hr/></div>"
      },
      "identifier" : [{
        "system" : "urn:oid:1.2.208.176.1.2",
        "value" : "2509479989"
      }],
      "name" : [{
        "use" : "official",
        "family" : "Elmer"
      }]
    }
  },
  {
    "fullUrl" : "https://medcomfhir.dk/ig/hospitalnotification/Encounter/7c08cb56-eb80-4979-855c-d8d75da9b01a",
    "resource" : {
      "resourceType" : "Encounter",
      "id" : "7c08cb56-eb80-4979-855c-d8d75da9b01a",
      "meta" : {
        "profile" : ["http://medcomfhir.dk/ig/hospitalnotification/StructureDefinition/medcom-hospitalNotification-encounter"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Encounter_7c08cb56-eb80-4979-855c-d8d75da9b01a\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Encounter 7c08cb56-eb80-4979-855c-d8d75da9b01a</b></p><a name=\"7c08cb56-eb80-4979-855c-d8d75da9b01a\"> </a><a name=\"hc7c08cb56-eb80-4979-855c-d8d75da9b01a\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-medcom-hospitalNotification-encounter.html\">MedComHospitalNotificationEncounter</a></p></div><p><b>status</b>: In Progress</p><p><b>class</b>: <a href=\"http://terminology.hl7.org/7.3.0/CodeSystem-v3-ActCode.html#v3-ActCode-EMER\">ActCode: EMER</a> (emergency)</p><p><b>subject</b>: <a href=\"Patient-34bff467-2813-42ac-a928-220a8433dfa9.html\">Elmer (official) (no stated gender), DoB Unknown ( urn:oid:1.2.208.176.1.2#DkCoreDanishCivilRegistrationSystem#2509479989)</a></p><p><b>episodeOfCare</b>: Identifier: <code>https://sor2.sum.dsdn.dk/#id=265161000016000</code>/c10697b6-8d7a-4d2d-ae93-f7f56abd52cc</p><p><b>period</b>: 2026-02-28 10:00:04+0100 --&gt; (ongoing)</p><p><b>serviceProvider</b>: <a href=\"Organization-41767586-090e-4242-bf50-0dfcaf8d80e0.html\">Organization Hjerteafdelingen på Herlev og Gentofte hospital</a></p></div>"
      },
      "status" : "in-progress",
      "class" : {
        "system" : "http://terminology.hl7.org/CodeSystem/v3-ActCode",
        "code" : "EMER"
      },
      "subject" : {
        "reference" : "Patient/34bff467-2813-42ac-a928-220a8433dfa9"
      },
      "episodeOfCare" : [{
        "identifier" : {
          "system" : "https://sor2.sum.dsdn.dk/#id=265161000016000",
          "value" : "c10697b6-8d7a-4d2d-ae93-f7f56abd52cc"
        }
      }],
      "period" : {
        "start" : "2026-02-28T10:00:04+01:00"
      },
      "serviceProvider" : {
        "reference" : "Organization/41767586-090e-4242-bf50-0dfcaf8d80e0"
      }
    }
  },
  {
    "fullUrl" : "https://medcomfhir.dk/ig/hospitalnotification/Organization/a3c6c488-9f80-4ae3-8c88-942053ca9234",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "a3c6c488-9f80-4ae3-8c88-942053ca9234",
      "meta" : {
        "profile" : ["http://medcomfhir.dk/ig/messaging/StructureDefinition/medcom-messaging-organization"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_a3c6c488-9f80-4ae3-8c88-942053ca9234\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization a3c6c488-9f80-4ae3-8c88-942053ca9234</b></p><a name=\"a3c6c488-9f80-4ae3-8c88-942053ca9234\"> </a><a name=\"hca3c6c488-9f80-4ae3-8c88-942053ca9234\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://medcomfhir.dk/ig/messaging/2.1.0/StructureDefinition-medcom-messaging-organization.html\">MedComMessagingOrganization</a></p></div><p><b>identifier</b>: <code>https://www.gs1.org/gln</code>/5790001348120, <code>urn:oid:1.2.208.176.1.1</code>/953741000016009</p><p><b>name</b>: Plejecenter Herlev</p></div>"
      },
      "identifier" : [{
        "system" : "https://www.gs1.org/gln",
        "value" : "5790001348120"
      },
      {
        "system" : "urn:oid:1.2.208.176.1.1",
        "value" : "953741000016009"
      }],
      "name" : "Plejecenter Herlev"
    }
  },
  {
    "fullUrl" : "https://medcomfhir.dk/ig/hospitalnotification/Organization/41767586-090e-4242-bf50-0dfcaf8d80e0",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "41767586-090e-4242-bf50-0dfcaf8d80e0",
      "meta" : {
        "profile" : ["http://medcomfhir.dk/ig/messaging/StructureDefinition/medcom-messaging-organization"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_41767586-090e-4242-bf50-0dfcaf8d80e0\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization 41767586-090e-4242-bf50-0dfcaf8d80e0</b></p><a name=\"41767586-090e-4242-bf50-0dfcaf8d80e0\"> </a><a name=\"hc41767586-090e-4242-bf50-0dfcaf8d80e0\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://medcomfhir.dk/ig/messaging/2.1.0/StructureDefinition-medcom-messaging-organization.html\">MedComMessagingOrganization</a></p></div><p><b>identifier</b>: <code>https://www.gs1.org/gln</code>/5790000209354, <code>urn:oid:1.2.208.176.1.1</code>/265161000016000</p><p><b>name</b>: Hjerteafdelingen på Herlev og Gentofte hospital</p></div>"
      },
      "identifier" : [{
        "system" : "https://www.gs1.org/gln",
        "value" : "5790000209354"
      },
      {
        "system" : "urn:oid:1.2.208.176.1.1",
        "value" : "265161000016000"
      }],
      "name" : "Hjerteafdelingen på Herlev og Gentofte hospital"
    }
  },
  {
    "fullUrl" : "https://medcomfhir.dk/ig/hospitalnotification/Provenance/98edf80f-388f-4ae0-b507-7e36b179b510",
    "resource" : {
      "resourceType" : "Provenance",
      "id" : "98edf80f-388f-4ae0-b507-7e36b179b510",
      "meta" : {
        "profile" : ["http://medcomfhir.dk/ig/messaging/StructureDefinition/medcom-messaging-provenance"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Provenance_98edf80f-388f-4ae0-b507-7e36b179b510\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Provenance 98edf80f-388f-4ae0-b507-7e36b179b510</b></p><a name=\"98edf80f-388f-4ae0-b507-7e36b179b510\"> </a><a name=\"hc98edf80f-388f-4ae0-b507-7e36b179b510\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://medcomfhir.dk/ig/messaging/2.1.0/StructureDefinition-medcom-messaging-provenance.html\">MedComMessagingProvenance</a></p></div><p>Provenance for <a href=\"MessageHeader-e0c738da-480c-4f64-97f8-d4479a47b9f5.html\">MessageHeader: extension = true,-&gt;Organization Hjerteafdelingen på Herlev og Gentofte hospital; event[x] = Hospital Notification Message (MedComMessagingEventCodes#hospital-notification-message)</a></p><p>Summary</p><table class=\"grid\"><tr><td>Occurrence</td><td>2026-02-28 10:00:06+0100</td></tr><tr><td>Recorded</td><td>2026-02-28 10:00:06+0100</td></tr><tr><td>Activity</td><td><span title=\"Codes:{http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-messaging-activityCodes admit-emergency}\">Start hospital stay - acute ambulant</span></td></tr></table><p><b>Agents</b></p><table class=\"grid\"><tr><td><b>who</b></td></tr><tr><td><a href=\"Organization-41767586-090e-4242-bf50-0dfcaf8d80e0.html\">Organization Hjerteafdelingen på Herlev og Gentofte hospital</a></td></tr></table></div>"
      },
      "target" : [{
        "reference" : "MessageHeader/e0c738da-480c-4f64-97f8-d4479a47b9f5"
      }],
      "occurredDateTime" : "2026-02-28T10:00:06+01:00",
      "recorded" : "2026-02-28T10:00:06+01:00",
      "activity" : {
        "coding" : [{
          "system" : "http://medcomfhir.dk/ig/terminology/CodeSystem/medcom-messaging-activityCodes",
          "code" : "admit-emergency"
        }]
      },
      "agent" : [{
        "who" : {
          "reference" : "Organization/41767586-090e-4242-bf50-0dfcaf8d80e0"
        }
      }]
    }
  }]
}

```
